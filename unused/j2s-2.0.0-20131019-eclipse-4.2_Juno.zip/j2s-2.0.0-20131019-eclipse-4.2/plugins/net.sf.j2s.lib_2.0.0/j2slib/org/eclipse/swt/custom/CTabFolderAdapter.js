$_L(["$wt.custom.CTabFolderListener"],"$wt.custom.CTabFolderAdapter",null,function(){
c$=$_T($wt.custom,"CTabFolderAdapter",null,$wt.custom.CTabFolderListener);
$_V(c$,"itemClosed",
function(event){
},"$wt.custom.CTabFolderEvent");
});
