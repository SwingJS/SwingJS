$_L(["$wt.internal.SWTEventListener"],"$wt.events.VerifyListener",null,function(){
$_I($wt.events,"VerifyListener",$wt.internal.SWTEventListener);
});
