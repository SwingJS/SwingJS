$_L(["$wt.internal.SWTEventObject"],"$wt.accessibility.AccessibleTextEvent",null,function(){
c$=$_C(function(){
this.childID=0;
this.offset=0;
this.length=0;
$_Z(this,arguments);
},$wt.accessibility,"AccessibleTextEvent",$wt.internal.SWTEventObject);
$_V(c$,"toString",
function(){
return"AccessibleTextEvent {childID="+this.childID+" offset="+this.offset+" length="+this.length+"}";
});
});
