$_L(["$wt.events.TypedEvent"],"$wt.events.MenuEvent",null,function(){
c$=$_T($wt.events,"MenuEvent",$wt.events.TypedEvent);
});
