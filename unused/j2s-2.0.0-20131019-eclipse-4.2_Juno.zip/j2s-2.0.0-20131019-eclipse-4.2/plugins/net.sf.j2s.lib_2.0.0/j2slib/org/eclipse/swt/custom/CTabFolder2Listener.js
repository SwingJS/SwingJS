$_L(["$wt.internal.SWTEventListener"],"$wt.custom.CTabFolder2Listener",null,function(){
$_I($wt.custom,"CTabFolder2Listener",$wt.internal.SWTEventListener);
});
