$_L(["$wt.internal.SWTEventListener"],"$wt.events.ModifyListener",null,function(){
$_I($wt.events,"ModifyListener",$wt.internal.SWTEventListener);
});
