$_J("net.sf.j2s.ajax");
c$=$_T(net.sf.j2s.ajax,"ThreadUtils");
$_S(c$,
"aes",null);
