$_J("net.sf.j2s.annotation");
$_L(["java.lang.annotation.ElementType"],,null,function(){
});
