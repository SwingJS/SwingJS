$_L(["java.util.ResourceBundle"],"java.util.ListResourceBundle",["java.util.Enumeration","$.Hashtable"],function(){
c$=$_C(function(){
this.table=null;
$_Z(this,arguments);
},java.util,"ListResourceBundle",java.util.ResourceBundle);
$_M(c$,"getKeys",
function(){
if(this.table==null){
this.initializeTable();
}if(this.parent==null){
return this.table.keys();
}return(($_D("java.util.ListResourceBundle$1")?0:java.util.ListResourceBundle.$ListResourceBundle$1$()),$_N(java.util.ListResourceBundle$1,this,null));
});
$_V(c$,"handleGetObject",
function(key){
if(this.table==null){
this.initializeTable();
}return this.table.get(key);
},"~S");
$_M(c$,"initializeTable",
($fz=function(){
if(this.table==null){
var contents=this.getContents();
this.table=new java.util.Hashtable($_dI(contents.length/3)*4+3);
for(var i=0;i<contents.length;i++){
this.table.put(contents[i][0],contents[i][1]);
}
}},$fz.isPrivate=true,$fz));
c$.$ListResourceBundle$1$=function(){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.local=null;
this.pEnum=null;
this.$nextElement=null;
$_Z(this,arguments);
},java.util,"ListResourceBundle$1",null,java.util.Enumeration);
$_Y(c$,function(){
this.local=this.b$["java.util.ListResourceBundle"].table.keys();
this.pEnum=this.b$["java.util.ListResourceBundle"].parent.getKeys();
});
$_M(c$,"findNext",
($fz=function(){
if(this.$nextElement!=null){
return true;
}while(this.pEnum.hasMoreElements()){
var next=this.pEnum.nextElement();
if(!this.b$["java.util.ListResourceBundle"].table.containsKey(next)){
this.$nextElement=next;
return true;
}}
return false;
},$fz.isPrivate=true,$fz));
$_M(c$,"hasMoreElements",
function(){
if(this.local.hasMoreElements()){
return true;
}return this.findNext();
});
$_M(c$,"nextElement",
function(){
if(this.local.hasMoreElements()){
return this.local.nextElement();
}if(this.findNext()){
var result=this.$nextElement;
this.$nextElement=null;
return result;
}return this.pEnum.nextElement();
});
c$=$_P();
};
});
