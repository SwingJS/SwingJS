$_L(["java.io.ObjectStreamException"],"java.io.InvalidObjectException",null,function(){
c$=$_T(java.io,"InvalidObjectException",java.io.ObjectStreamException);
});
