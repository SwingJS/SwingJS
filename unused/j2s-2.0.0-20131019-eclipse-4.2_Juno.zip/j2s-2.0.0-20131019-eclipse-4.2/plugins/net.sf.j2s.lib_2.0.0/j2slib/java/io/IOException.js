$_L(["java.lang.Exception"],"java.io.IOException",null,function(){
c$=$_T(java.io,"IOException",Exception);
});
