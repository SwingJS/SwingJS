$_L(["java.lang.IndexOutOfBoundsException"],"java.lang.ArrayIndexOutOfBoundsException",null,function(){
c$=$_T(java.lang,"ArrayIndexOutOfBoundsException",IndexOutOfBoundsException);
$_K(c$,
function(index){
$_R(this,ArrayIndexOutOfBoundsException,["Array index out of range: "+index]);
},"~N");
});
