$_L(["java.security.BasicPermission"],"java.lang.reflect.ReflectPermission",null,function(){
c$=$_T(java.lang.reflect,"ReflectPermission",java.security.BasicPermission);
});
