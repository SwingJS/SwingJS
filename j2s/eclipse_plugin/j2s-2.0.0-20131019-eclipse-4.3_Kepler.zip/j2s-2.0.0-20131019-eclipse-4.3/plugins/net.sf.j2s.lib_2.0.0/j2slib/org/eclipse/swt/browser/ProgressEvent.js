$_L(["$wt.events.TypedEvent"],"$wt.browser.ProgressEvent",null,function(){
c$=$_C(function(){
this.current=0;
this.total=0;
$_Z(this,arguments);
},$wt.browser,"ProgressEvent",$wt.events.TypedEvent);
});
