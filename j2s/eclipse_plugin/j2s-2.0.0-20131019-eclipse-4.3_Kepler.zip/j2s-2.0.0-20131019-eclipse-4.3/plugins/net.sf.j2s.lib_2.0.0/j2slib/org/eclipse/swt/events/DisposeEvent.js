$_L(["$wt.events.TypedEvent"],"$wt.events.DisposeEvent",null,function(){
c$=$_T($wt.events,"DisposeEvent",$wt.events.TypedEvent);
});
