$_L(["$wt.internal.SWTEventListener"],"$wt.custom.ExtendedModifyListener",null,function(){
$_I($wt.custom,"ExtendedModifyListener",$wt.internal.SWTEventListener);
});
