$_L(["$wt.internal.SWTEventListener"],"$wt.events.MenuDetectListener",null,function(){
$_I($wt.events,"MenuDetectListener",$wt.internal.SWTEventListener);
});
