$_I(java.util,"Map");
$_I(java.util.Map,"Entry");
