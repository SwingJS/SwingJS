$_L(["java.util.Collection"],"java.util.Set",null,function(){
$_I(java.util,"Set",java.util.Collection);
});
