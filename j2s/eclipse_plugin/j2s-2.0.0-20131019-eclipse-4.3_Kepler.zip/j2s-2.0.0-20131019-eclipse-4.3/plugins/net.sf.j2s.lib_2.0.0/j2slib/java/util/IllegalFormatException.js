$_L(["java.lang.IllegalArgumentException"],"java.util.IllegalFormatException",null,function(){
c$=$_T(java.util,"IllegalFormatException",IllegalArgumentException,java.io.Serializable);
$_K(c$,
function(){
$_R(this,java.util.IllegalFormatException,[]);
});
});
