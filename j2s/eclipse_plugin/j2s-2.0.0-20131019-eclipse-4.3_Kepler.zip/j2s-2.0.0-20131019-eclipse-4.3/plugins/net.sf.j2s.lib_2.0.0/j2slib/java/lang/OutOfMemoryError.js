$_L(["java.lang.VirtualMachineError"],"java.lang.OutOfMemoryError",null,function(){
c$=$_T(java.lang,"OutOfMemoryError",VirtualMachineError);
});
