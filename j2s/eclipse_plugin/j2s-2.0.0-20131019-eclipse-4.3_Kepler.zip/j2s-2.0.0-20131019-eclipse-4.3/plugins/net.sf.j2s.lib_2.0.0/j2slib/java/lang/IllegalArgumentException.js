$_L(["java.lang.RuntimeException"],"java.lang.IllegalArgumentException",null,function(){
c$=$_T(java.lang,"IllegalArgumentException",RuntimeException);
$_K(c$,
function(cause){
$_R(this,IllegalArgumentException,[(cause==null?null:cause.toString()),cause]);
},"Throwable");
});
