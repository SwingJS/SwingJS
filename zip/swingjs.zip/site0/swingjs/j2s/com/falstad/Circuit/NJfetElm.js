Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.JfetElm"], ["com.falstad.Circuit.NJfetElm", "$.PJfetElm"], null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "NJfetElm", com.falstad.Circuit.JfetElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.NJfetElm, [xx, yy, false]);
}, "~N,~N");
Clazz.overrideMethod (c$, "getDumpClass", 
function () {
return com.falstad.Circuit.JfetElm;
});
c$ = Clazz.declareType (com.falstad.Circuit, "PJfetElm", com.falstad.Circuit.JfetElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.PJfetElm, [xx, yy, true]);
}, "~N,~N");
Clazz.overrideMethod (c$, "getDumpClass", 
function () {
return com.falstad.Circuit.JfetElm;
});
});
