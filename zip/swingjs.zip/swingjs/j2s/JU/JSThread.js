Clazz.declarePackage ("JU");
Clazz.load (["java.lang.Thread", "javajs.api.JSFunction"], "JU.JSThread", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.isJS = false;
Clazz.instantialize (this, arguments);
}, JU, "JSThread", Thread, javajs.api.JSFunction);
Clazz.makeConstructor (c$, 
function () {
this.construct (null, "JSThread-" + (++JU.JSThread.threadCount));
});
Clazz.makeConstructor (c$, 
function (name) {
this.construct (null, name);
}, "~S");
Clazz.makeConstructor (c$, 
function (group, name) {
Clazz.superConstructor (this, JU.JSThread, [group, name]);
{
this.isJS = true;
}}, "ThreadGroup,~S");
Clazz.overrideMethod (c$, "run", 
function () {
this.run1 (0);
});
Clazz.defineMethod (c$, "start", 
function () {
{
swingjs.JSToolkit.dispatch(this, 1, 0);
}});
Clazz.defineMethod (c$, "run1", 
function (state) {
var executeFinally = true;
try {
while (!Thread.interrupted ()) {
switch (state) {
case 0:
if (!this.myInit ()) return;
state = 1;
continue;
case 1:
if (!this.isLooping ()) {
state = 2;
continue;
}if (this.myLoop () && this.sleepAndReturn (this.getDelayMillis (), state)) {
executeFinally = false;
return;
}continue;
case 2:
this.whenDone ();
return;
}
}
} catch (e) {
if (Clazz.exceptionOf (e, Exception)) {
this.onException (e);
state = 2;
} else {
throw e;
}
} finally {
if (executeFinally) this.doFinally ();
}
}, "~N");
Clazz.defineMethod (c$, "sleepAndReturn", 
function (delay, state) {
if (!this.isJS) {
Thread.sleep (delay);
return false;
}var me = this;
var r = ((Clazz.isClassDefined ("JU.JSThread$1") ? 0 : JU.JSThread.$JSThread$1$ ()), Clazz.innerTypeInstance (JU.JSThread$1, this, {me: me, state: state}));
{
setTimeout(
function() {java.awt.Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(new java.awt.event.InvocationEvent(me, r))},
delay
);
}return true;
}, "~N,~N");
c$.$JSThread$1$ = function () {
Clazz.pu$h (c$);
c$ = Clazz.declareAnonymous (JU, "JSThread$1", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
this.f$.me.run1 (this.f$.state);
});
var rc = c$;
c$ = Clazz.p0p ();
return rc;
};
Clazz.defineStatics (c$,
"INIT", 0,
"LOOP", 1,
"DONE", 2,
"threadCount", 0);
});
