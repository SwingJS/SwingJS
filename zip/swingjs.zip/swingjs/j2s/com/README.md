This directory is included only for demonstration of SwingJS capabilities.
