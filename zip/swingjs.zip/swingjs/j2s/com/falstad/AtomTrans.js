Clazz.declarePackage ("com.falstad");
Clazz.load (["a2s.Applet", "$.Canvas", "$.Frame", "com.falstad.Complex", "java.awt.LayoutManager", "$.Rectangle", "java.awt.event.ActionListener", "$.AdjustmentListener", "$.ComponentListener", "$.ItemListener", "$.MouseListener", "$.MouseMotionListener"], ["com.falstad.AtomTrans", "$.AtomTransCanvas", "$.AtomTransFrame", "$.AtomTransLayout"], ["a2s.Checkbox", "$.CheckboxMenuItem", "$.Choice", "$.Label", "$.Menu", "$.MenuBar", "$.MenuItem", "$.Scrollbar", "java.awt.Color", "$.Dimension", "java.awt.image.MemoryImageSource", "java.util.Random"], function () {
c$ = Clazz.decorateAsClass (function () {
this.pg = null;
Clazz.instantialize (this, arguments);
}, com.falstad, "AtomTransCanvas", a2s.Canvas);
Clazz.makeConstructor (c$, 
function (p) {
Clazz.superConstructor (this, com.falstad.AtomTransCanvas, []);
this.pg = p;
}, "com.falstad.AtomTransFrame");
Clazz.overrideMethod (c$, "getPreferredSize", 
function () {
return  new java.awt.Dimension (300, 400);
});
Clazz.overrideMethod (c$, "update", 
function (g) {
this.pg.updateAtomTrans (g);
}, "java.awt.Graphics");
Clazz.overrideMethod (c$, "paintComponent", 
function (g) {
this.pg.updateAtomTrans (g);
}, "java.awt.Graphics");
c$ = Clazz.declareType (com.falstad, "AtomTransLayout", null, java.awt.LayoutManager);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.overrideMethod (c$, "addLayoutComponent", 
function (name, c) {
}, "~S,java.awt.Component");
Clazz.overrideMethod (c$, "removeLayoutComponent", 
function (c) {
}, "java.awt.Component");
Clazz.overrideMethod (c$, "preferredLayoutSize", 
function (target) {
return  new java.awt.Dimension (500, 500);
}, "java.awt.Container");
Clazz.overrideMethod (c$, "minimumLayoutSize", 
function (target) {
return  new java.awt.Dimension (100, 100);
}, "java.awt.Container");
Clazz.overrideMethod (c$, "layoutContainer", 
function (target) {
var barwidth = 0;
var i;
for (i = 1; i < target.getComponentCount (); i++) {
var m = target.getComponent (i);
if (m.isVisible ()) {
var d = m.getPreferredSize ();
if (d.width > barwidth) barwidth = d.width;
}}
var insets = target.insets ();
var targetw = target.size ().width - insets.left - insets.right;
var cw = targetw - barwidth;
var targeth = target.size ().height - (insets.top + insets.bottom);
target.getComponent (0).move (insets.left, insets.top);
target.getComponent (0).resize (cw, targeth);
cw += insets.left;
var h = insets.top;
for (i = 1; i < target.getComponentCount (); i++) {
var m = target.getComponent (i);
if (m.isVisible ()) {
var d = m.getPreferredSize ();
if (Clazz.instanceOf (m, a2s.Scrollbar)) d.width = barwidth;
if (Clazz.instanceOf (m, a2s.Choice) && d.width > barwidth) d.width = barwidth;
if (Clazz.instanceOf (m, a2s.Label)) {
h += Clazz.doubleToInt (d.height / 5);
d.width = barwidth;
}m.move (cw, h);
m.resize (d.width, d.height);
h += d.height;
}}
}, "java.awt.Container");
c$ = Clazz.decorateAsClass (function () {
this.started = false;
Clazz.instantialize (this, arguments);
}, com.falstad, "AtomTrans", a2s.Applet, java.awt.event.ComponentListener);
Clazz.defineMethod (c$, "destroyFrame", 
function () {
if (com.falstad.AtomTrans.ogf != null) com.falstad.AtomTrans.ogf.dispose ();
com.falstad.AtomTrans.ogf = null;
this.repaint ();
});
Clazz.overrideMethod (c$, "init", 
function () {
this.addComponentListener (this);
});
c$.main = Clazz.defineMethod (c$, "main", 
function (args) {
com.falstad.AtomTrans.ogf =  new com.falstad.AtomTransFrame (null);
com.falstad.AtomTrans.ogf.init ();
}, "~A");
Clazz.defineMethod (c$, "showFrame", 
function () {
if (com.falstad.AtomTrans.ogf == null) {
this.started = true;
com.falstad.AtomTrans.ogf =  new com.falstad.AtomTransFrame (this);
com.falstad.AtomTrans.ogf.init ();
this.repaint ();
}});
Clazz.defineMethod (c$, "paint", 
function (g) {
Clazz.superCall (this, com.falstad.AtomTrans, "paint", [g]);
var s = "Applet is open in a separate window.";
if (!this.started) s = "Applet is starting.";
 else if (com.falstad.AtomTrans.ogf == null) s = "Applet is finished.";
 else com.falstad.AtomTrans.ogf.show ();
g.drawString (s, 10, 30);
}, "java.awt.Graphics");
Clazz.overrideMethod (c$, "componentHidden", 
function (e) {
}, "java.awt.event.ComponentEvent");
Clazz.overrideMethod (c$, "componentMoved", 
function (e) {
}, "java.awt.event.ComponentEvent");
Clazz.overrideMethod (c$, "componentShown", 
function (e) {
this.showFrame ();
}, "java.awt.event.ComponentEvent");
Clazz.overrideMethod (c$, "componentResized", 
function (e) {
}, "java.awt.event.ComponentEvent");
Clazz.overrideMethod (c$, "destroy", 
function () {
if (com.falstad.AtomTrans.ogf != null) com.falstad.AtomTrans.ogf.dispose ();
com.falstad.AtomTrans.ogf = null;
this.repaint ();
});
Clazz.defineStatics (c$,
"ogf", null);
c$ = Clazz.decorateAsClass (function () {
this.engine = null;
this.winSize = null;
this.dbimage = null;
this.memimage = null;
this.random = null;
this.gridSizeX = 200;
this.gridSizeY = 200;
this.blankButton = null;
this.stoppedCheck = null;
this.colorCheck = null;
this.eCheckItem = null;
this.xCheckItem = null;
this.restrictItem = null;
this.dimensionsItem = null;
this.axesItem = null;
this.autoZoomItem = null;
this.animatedZoomItem = null;
this.exitItem = null;
this.sliceChooser = null;
this.freqChooser = null;
this.dirChooser = null;
this.setupChooser = null;
this.speedBar = null;
this.strengthBar = null;
this.stepBar = null;
this.resolutionBar = null;
this.internalResBar = null;
this.brightnessBar = null;
this.scaleBar = null;
this.sampleBar = null;
this.viewPotential = null;
this.viewX = null;
this.viewStates = null;
this.viewList = null;
this.viewCount = 0;
this.orbitals = null;
this.orbCount = 0;
this.phasors = null;
this.phasorCount = 0;
this.states = null;
this.stateCount = 0;
this.newcoef = null;
this.dragZoomStart = 0;
this.lastXRot = 0;
this.lastYRot = 0;
this.colorMult = 0;
this.zoom = 0;
this.rotmatrix = null;
this.viewAxes = null;
this.viewField = null;
this.xpoints = null;
this.ypoints = null;
this.selectedPaneHandle = 0;
this.freqMax = 0;
this.freq = 0;
this.freqPhase = 0;
this.phaseColors = null;
this.purple = null;
this.resadj = 0;
this.dragging = false;
this.imageSource = null;
this.pixels = null;
this.sampleCount = 0;
this.dataSize = 0;
this.pause = 0;
this.applet = null;
this.selectedState = null;
this.selectedPhasor = null;
this.selection = -1;
this.slicerPoints = null;
this.sliceFaces = null;
this.sliceFace = null;
this.sliceFaceCount = 0;
this.sliceval = 0;
this.sampleMult = null;
this.selectedSlice = false;
this.settingScale = false;
this.magDragStart = 0;
this.dragX = 0;
this.dragY = 0;
this.dragStartX = 0;
this.dragStartY = 0;
this.t = 0;
this.funcr = 0;
this.funci = 0;
this.phiIndex = 0;
this.bestBrightness = 0;
this.userBrightMult = 1;
this.manualScale = false;
this.gray2 = null;
this.fontMetrics = null;
this.cv = null;
this.useBufferedImage = false;
this.lastFrameTime = 0;
this.dipoleOpX = null;
this.dipoleOpY = null;
this.dipoleOpZ = null;
this.scaleValue = -1;
if (!Clazz.isClassDefined ("com.falstad.AtomTransFrame.Orbital")) {
com.falstad.AtomTransFrame.$AtomTransFrame$Orbital$ ();
}
if (!Clazz.isClassDefined ("com.falstad.AtomTransFrame.SOrbital")) {
com.falstad.AtomTransFrame.$AtomTransFrame$SOrbital$ ();
}
if (!Clazz.isClassDefined ("com.falstad.AtomTransFrame.MZeroOrbital")) {
com.falstad.AtomTransFrame.$AtomTransFrame$MZeroOrbital$ ();
}
if (!Clazz.isClassDefined ("com.falstad.AtomTransFrame.PairedOrbital")) {
com.falstad.AtomTransFrame.$AtomTransFrame$PairedOrbital$ ();
}
if (!Clazz.isClassDefined ("com.falstad.AtomTransFrame.Phasor")) {
com.falstad.AtomTransFrame.$AtomTransFrame$Phasor$ ();
}
if (!Clazz.isClassDefined ("com.falstad.AtomTransFrame.State")) {
com.falstad.AtomTransFrame.$AtomTransFrame$State$ ();
}
if (!Clazz.isClassDefined ("com.falstad.AtomTransFrame.BasisState")) {
com.falstad.AtomTransFrame.$AtomTransFrame$BasisState$ ();
}
if (!Clazz.isClassDefined ("com.falstad.AtomTransFrame.PhaseColor")) {
com.falstad.AtomTransFrame.$AtomTransFrame$PhaseColor$ ();
}
if (!Clazz.isClassDefined ("com.falstad.AtomTransFrame.View")) {
com.falstad.AtomTransFrame.$AtomTransFrame$View$ ();
}
this.setups = null;
this.setupStrings = null;
Clazz.instantialize (this, arguments);
}, com.falstad, "AtomTransFrame", a2s.Frame, [java.awt.event.ComponentListener, java.awt.event.ActionListener, java.awt.event.AdjustmentListener, java.awt.event.MouseMotionListener, java.awt.event.MouseListener, java.awt.event.ItemListener]);
Clazz.prepareFields (c$, function () {
this.dipoleOpX =  Clazz.newDoubleArray (-1, [0., 0., 0., 0., 0., 0.526749, 0., -0.526749, 0.210938, 0., -0.210938, 0.124346, 0., -0.124346, 0.085203, 0., -0.085203, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -2.12132, 0., 2.12132, 1.25121, 0., -1.25121, 0.523487, 0., -0.523487, 0.315964, 0., -0.315964, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.383102, 0., -0.383102, -5.19615, 0., 5.19615, 2.23285, 0., -2.23285, 0.922468, 0., -0.922468, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.156074, 0., -0.156074, 0.997569, 0., -0.997569, -9.48683, 0., 9.48683, 3.47739, 0., -3.47739, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.0930919, 0., -0.0930919, 0.395842, 0., -0.395842, 1.87806, 0., -1.87806, -15.0, 0., 15., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.526749, -2.12132, 0.383102, 0.156074, 0.0930919, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 2.12337, 0., -0.866861, 0., 0., 0.764602, 0., -0.312148, 0., 0., 0.436072, 0., -0.178026, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1.50145, 0., -1.50145, 0., 0., 0.540655, 0., -0.540655, 0., 0., 0.30835, 0., -0.30835, 0., -0.526749, 2.12132, -0.383102, -0.156074, -0.0930919, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.866861, 0., -2.12337, 0., 0., 0.312148, 0., -0.764602, 0., 0., 0.178026, 0., -0.436072, 0.210938, 1.25121, -5.19615, 0.997569, 0.395842, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -4.5, 0., 1.83712, 0., 0., 3.38335, 0., -1.38125, 0., 0., 1.32747, 0., -0.541939, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -3.18198, 0., 3.18198, 0., 0., 2.39239, 0., -2.39239, 0., 0., 0.938666, 0., -0.938666, 0., -0.210938, -1.25121, 5.19615, -0.997569, -0.395842, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -1.83712, 0., 4.5, 0., 0., 1.38125, 0., -3.38335, 0., 0., 0.541939, 0., -1.32747, 0.124346, 0.523487, 2.23285, -9.48683, 1.87806, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.582386, 0., -0.237758, 0., 0., -9.29516, 0., 3.79473, 0., 0., 4.93677, 0., -2.01543, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.411809, 0., -0.411809, 0., 0., -6.57267, 0., 6.57267, 0., 0., 3.49082, 0., -3.49082, 0., -0.124346, -0.523487, -2.23285, 9.48683, -1.87806, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.237758, 0., -0.582386, 0., 0., -3.79473, 0., 9.29516, 0., 0., 2.01543, 0., -4.93677, 0.085203, 0.315964, 0.922468, 3.47739, -15.0, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.215914, 0., -0.0881464, 0., 0., 1.36191, 0., -0.555997, 0., 0., -15.3704, 0., 6.27495, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.152674, 0., -0.152674, 0., 0., 0.963015, 0., -0.963015, 0., 0., -10.8685, 0., 10.8685, 0., -0.085203, -0.315964, -0.922468, -3.47739, 15., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.0881464, 0., -0.215914, 0., 0., 0.555997, 0., -1.36191, 0., 0., -6.27495, 0., 15.3704, 0., 0., 0., 0., 0., 2.12337, 0., 0., -4.5, 0., 0., 0.582386, 0., 0., 0.215914, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1.50145, 0., 0., -3.18198, 0., 0., 0.411809, 0., 0., 0.152674, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.866861, 0., 0.866861, 1.83712, 0., -1.83712, -0.237758, 0., 0.237758, -0.0881464, 0., 0.0881464, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -1.50145, 0., 0., 3.18198, 0., 0., -0.411809, 0., 0., -0.152674, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -2.12337, 0., 0., 4.5, 0., 0., -0.582386, 0., 0., -0.215914, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.764602, 0., 0., 3.38335, 0., 0., -9.29516, 0., 0., 1.36191, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.540655, 0., 0., 2.39239, 0., 0., -6.57267, 0., 0., 0.963015, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.312148, 0., 0.312148, -1.38125, 0., 1.38125, 3.79473, 0., -3.79473, -0.555997, 0., 0.555997, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.540655, 0., 0., -2.39239, 0., 0., 6.57267, 0., 0., -0.963015, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.764602, 0., 0., -3.38335, 0., 0., 9.29516, 0., 0., -1.36191, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.436072, 0., 0., 1.32747, 0., 0., 4.93677, 0., 0., -15.3704, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.30835, 0., 0., 0.938666, 0., 0., 3.49082, 0., 0., -10.8685, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.178026, 0., 0.178026, -0.541939, 0., 0.541939, -2.01543, 0., 2.01543, 6.27495, 0., -6.27495, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.30835, 0., 0., -0.938666, 0., 0., -3.49082, 0., 0., 10.8685, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.436072, 0., 0., -1.32747, 0., 0., -4.93677, 0., 0., 15.3704, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.]);
this.dipoleOpY =  Clazz.newDoubleArray (-1, [0., 0., 0., 0., 0., 0.526749, 0., 0.526749, 0.210938, 0., 0.210938, 0.124346, 0., 0.124346, 0.085203, 0., 0.085203, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -2.12132, 0., -2.12132, 1.25121, 0., 1.25121, 0.523487, 0., 0.523487, 0.315964, 0., 0.315964, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.383102, 0., 0.383102, -5.19615, 0., -5.19615, 2.23285, 0., 2.23285, 0.922468, 0., 0.922468, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.156074, 0., 0.156074, 0.997569, 0., 0.997569, -9.48683, 0., -9.48683, 3.47739, 0., 3.47739, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.0930919, 0., 0.0930919, 0.395842, 0., 0.395842, 1.87806, 0., 1.87806, -15.0, 0., -15.0, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.526749, 2.12132, -0.383102, -0.156074, -0.0930919, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 2.12337, 0., 0.866861, 0., 0., 0.764602, 0., 0.312148, 0., 0., 0.436072, 0., 0.178026, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1.50145, 0., 1.50145, 0., 0., 0.540655, 0., 0.540655, 0., 0., 0.30835, 0., 0.30835, 0., -0.526749, 2.12132, -0.383102, -0.156074, -0.0930919, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.866861, 0., 2.12337, 0., 0., 0.312148, 0., 0.764602, 0., 0., 0.178026, 0., 0.436072, -0.210938, -1.25121, 5.19615, -0.997569, -0.395842, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -4.5, 0., -1.83712, 0., 0., 3.38335, 0., 1.38125, 0., 0., 1.32747, 0., 0.541939, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -3.18198, 0., -3.18198, 0., 0., 2.39239, 0., 2.39239, 0., 0., 0.938666, 0., 0.938666, 0., -0.210938, -1.25121, 5.19615, -0.997569, -0.395842, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -1.83712, 0., -4.5, 0., 0., 1.38125, 0., 3.38335, 0., 0., 0.541939, 0., 1.32747, -0.124346, -0.523487, -2.23285, 9.48683, -1.87806, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.582386, 0., 0.237758, 0., 0., -9.29516, 0., -3.79473, 0., 0., 4.93677, 0., 2.01543, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.411809, 0., 0.411809, 0., 0., -6.57267, 0., -6.57267, 0., 0., 3.49082, 0., 3.49082, 0., -0.124346, -0.523487, -2.23285, 9.48683, -1.87806, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.237758, 0., 0.582386, 0., 0., -3.79473, 0., -9.29516, 0., 0., 2.01543, 0., 4.93677, -0.085203, -0.315964, -0.922468, -3.47739, 15., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.215914, 0., 0.0881464, 0., 0., 1.36191, 0., 0.555997, 0., 0., -15.3704, 0., -6.27495, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.152674, 0., 0.152674, 0., 0., 0.963015, 0., 0.963015, 0., 0., -10.8685, 0., -10.8685, 0., -0.085203, -0.315964, -0.922468, -3.47739, 15., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.0881464, 0., 0.215914, 0., 0., 0.555997, 0., 1.36191, 0., 0., -6.27495, 0., -15.3704, 0., 0., 0., 0., 0., -2.12337, 0., 0., 4.5, 0., 0., -0.582386, 0., 0., -0.215914, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -1.50145, 0., 0., 3.18198, 0., 0., -0.411809, 0., 0., -0.152674, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.866861, 0., -0.866861, 1.83712, 0., 1.83712, -0.237758, 0., -0.237758, -0.0881464, 0., -0.0881464, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -1.50145, 0., 0., 3.18198, 0., 0., -0.411809, 0., 0., -0.152674, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -2.12337, 0., 0., 4.5, 0., 0., -0.582386, 0., 0., -0.215914, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.764602, 0., 0., -3.38335, 0., 0., 9.29516, 0., 0., -1.36191, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.540655, 0., 0., -2.39239, 0., 0., 6.57267, 0., 0., -0.963015, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.312148, 0., -0.312148, -1.38125, 0., -1.38125, 3.79473, 0., 3.79473, -0.555997, 0., -0.555997, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.540655, 0., 0., -2.39239, 0., 0., 6.57267, 0., 0., -0.963015, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.764602, 0., 0., -3.38335, 0., 0., 9.29516, 0., 0., -1.36191, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.436072, 0., 0., -1.32747, 0., 0., -4.93677, 0., 0., 15.3704, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.30835, 0., 0., -0.938666, 0., 0., -3.49082, 0., 0., 10.8685, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.178026, 0., -0.178026, -0.541939, 0., -0.541939, -2.01543, 0., -2.01543, 6.27495, 0., 6.27495, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.30835, 0., 0., -0.938666, 0., 0., -3.49082, 0., 0., 10.8685, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -0.436072, 0., 0., -1.32747, 0., 0., -4.93677, 0., 0., 15.3704, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.]);
this.dipoleOpZ =  Clazz.newDoubleArray (-1, [0., 0., 0., 0., 0., 0., 0.744936, 0., 0., 0.298311, 0., 0., 0.175852, 0., 0., 0.120495, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -3.0, 0., 0., 1.76947, 0., 0., 0.740323, 0., 0., 0.446841, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.541788, 0., 0., -7.34847, 0., 0., 3.15772, 0., 0., 1.30457, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.220722, 0., 0., 1.41077, 0., 0., -13.4164, 0., 0., 4.91777, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.131652, 0., 0., 0.559805, 0., 0., 2.65597, 0., 0., -21.2132, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 2.12337, 0., 0., 0., 0., 0.764602, 0., 0., 0., 0., 0.436072, 0., 0., 0., 0.744936, -3.0, 0.541788, 0.220722, 0.131652, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 2.45185, 0., 0., 0., 0., 0.882887, 0., 0., 0., 0., 0.503533, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 2.12337, 0., 0., 0., 0., 0.764602, 0., 0., 0., 0., 0.436072, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -4.5, 0., 0., 0., 0., 3.38335, 0., 0., 0., 0., 1.32747, 0., 0., 0., 0.298311, 1.76947, -7.34847, 1.41077, 0.559805, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -5.19615, 0., 0., 0., 0., 3.90676, 0., 0., 0., 0., 1.53283, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., -4.5, 0., 0., 0., 0., 3.38335, 0., 0., 0., 0., 1.32747, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.582386, 0., 0., 0., 0., -9.29516, 0., 0., 0., 0., 4.93677, 0., 0., 0., 0.175852, 0.740323, 3.15772, -13.4164, 2.65597, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.672481, 0., 0., 0., 0., -10.7331, 0., 0., 0., 0., 5.70049, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.582386, 0., 0., 0., 0., -9.29516, 0., 0., 0., 0., 4.93677, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.215914, 0., 0., 0., 0., 1.36191, 0., 0., 0., 0., -15.3704, 0., 0., 0., 0.120495, 0.446841, 1.30457, 4.91777, -21.2132, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.249316, 0., 0., 0., 0., 1.5726, 0., 0., 0., 0., -17.7482, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.215914, 0., 0., 0., 0., 1.36191, 0., 0., 0., 0., -15.3704, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 2.12337, 0., 0., -4.5, 0., 0., 0.582386, 0., 0., 0.215914, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 2.45185, 0., 0., -5.19615, 0., 0., 0.672481, 0., 0., 0.249316, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 2.12337, 0., 0., -4.5, 0., 0., 0.582386, 0., 0., 0.215914, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.764602, 0., 0., 3.38335, 0., 0., -9.29516, 0., 0., 1.36191, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.882887, 0., 0., 3.90676, 0., 0., -10.7331, 0., 0., 1.5726, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.764602, 0., 0., 3.38335, 0., 0., -9.29516, 0., 0., 1.36191, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.436072, 0., 0., 1.32747, 0., 0., 4.93677, 0., 0., -15.3704, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.503533, 0., 0., 1.53283, 0., 0., 5.70049, 0., 0., -17.7482, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.436072, 0., 0., 1.32747, 0., 0., 4.93677, 0., 0., -15.3704, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.]);
this.setups =  Clazz.newIntArray (-1, [0, 15, 149, 1191, 0, 1, 0, 0, 15, 149, 1191, 2, 1, 0, 0, 15, 149, 1191, 3, 0, 0, 0, 22, 161, 1334, 2, 1, 1, 1, 27, 127, 1381, 2, 1, 3, 1, 27, 127, 1381, 3, 0, 3, 2, 27, 127, 1429, 4, 2, 3, 4, 27, 127, 1429, 3, 2, 3, 4, 27, 127, 1429, 0, 1, 3, 3, 27, 127, 1429, 2, 1, 3, 2, 27, 127, 1429, 2, 2, 3, 5, 27, 127, 1429, 2, 1, 3, 4, 27, 127, 1429, 2, 1, 3, 1, 27, 127, 1572, 2, 1, 4, 2, 38, 109, 1334, 3, 0, 3]);
this.setupStrings =  Clazz.newArray (-1, ["1s -> 2px", "1s -> 2pz", "1s -> 2p+1", "1s -> 3pz", "2s -> 3pz", "2s -> 3p+1", "2p+1 -> 3s+3dz2", "2pz -> 3d+1", "2pz -> 3dxz", "2px -> 3dxz", "2p+1 -> 3d+1", "3s -> 3dz2+3s", "2pz -> 3dz2", "2s -> 4pz", "2p+1 -> 3d+2", null]);
});
Clazz.defineMethod (c$, "getAppletInfo", 
function () {
return "AtomTrans by Paul Falstad";
});
Clazz.defineMethod (c$, "getrand", 
function (x) {
var q = this.random.nextInt ();
if (q < 0) q = -q;
return q % x;
}, "~N");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, com.falstad.AtomTransFrame, ["Atomic Dipole Transitions Applet v1.5a"]);
this.applet = a;
}, "com.falstad.AtomTrans");
Clazz.defineMethod (c$, "init", 
function () {
var $private = Clazz.checkPrivateMethod (arguments);
if ($private != null) {
return $private.apply (this, arguments);
}
this.gray2 =  new java.awt.Color (127, 127, 127);
var os = System.getProperty ("os.name");
var jv = System.getProperty ("java.version");
var altRender = false;
var res = 64;
this.setLayout ( new com.falstad.AtomTransLayout ());
this.cv =  new com.falstad.AtomTransCanvas (this);
this.cv.addComponentListener (this);
this.cv.addMouseMotionListener (this);
this.cv.addMouseListener (this);
this.add (this.cv);
var mb =  new a2s.MenuBar ();
var m =  new a2s.Menu ("File");
mb.add (m);
m.add (this.exitItem = this.getMenuItem ("Exit"));
m =  new a2s.Menu ("View");
mb.add (m);
m.add (this.eCheckItem = this.getCheckItem ("Energy"));
this.eCheckItem.setState (true);
m.add (this.xCheckItem = this.getCheckItem ("Position"));
this.xCheckItem.setState (true);
this.xCheckItem.disable ();
m.addSeparator ();
m.add (this.colorCheck = this.getCheckItem ("Phase as Color"));
this.colorCheck.setState (true);
m =  new a2s.Menu ("Options");
mb.add (m);
this.restrictItem = this.getCheckItem ("Restrict to N1, N2");
this.restrictItem.setState (true);
m.add (this.dimensionsItem = this.getCheckItem ("Show Dimensions"));
m.add (this.axesItem = this.getCheckItem ("Show Axes"));
this.axesItem.setState (true);
this.autoZoomItem = this.getCheckItem ("Auto Scale");
this.autoZoomItem.setState (true);
this.animatedZoomItem = this.getCheckItem ("Animated Scaling");
this.animatedZoomItem.setState (true);
this.setMenuBar (mb);
var i;
this.setupChooser =  new a2s.Choice ();
for (i = 0; this.setupStrings[i] != null; i++) this.setupChooser.add (this.setupStrings[i]);

this.setupChooser.addItemListener (this);
this.add (this.setupChooser);
this.sliceChooser =  new a2s.Choice ();
this.sliceChooser.add ("No Slicing");
this.sliceChooser.add ("Show X Slice");
this.sliceChooser.add ("Show Y Slice");
this.sliceChooser.add ("Show Z Slice");
this.sliceChooser.addItemListener (this);
this.add (this.sliceChooser);
this.freqChooser =  new a2s.Choice ();
this.freqChooser.add ("Freq = n=1 <-> n=2");
this.freqChooser.add ("Freq = n=1 <-> n=3");
this.freqChooser.add ("Freq = n=1 <-> n=4");
this.freqChooser.add ("Freq = n=2 <-> n=3");
this.freqChooser.add ("Freq = n=2 <-> n=4");
this.freqChooser.add ("Freq = n=3 <-> n=4");
this.freqChooser.addItemListener (this);
this.dirChooser =  new a2s.Choice ();
this.dirChooser.add ("X Dir");
this.dirChooser.add ("Y Dir");
this.dirChooser.add ("Z Dir");
this.dirChooser.add ("CCW Circular");
this.dirChooser.add ("CW Circular");
this.dirChooser.addItemListener (this);
this.stoppedCheck =  new a2s.Checkbox ("Stopped");
this.stoppedCheck.addItemListener (this);
this.add (this.stoppedCheck);
this.add ( new a2s.Label ("Simulation Speed", 0));
this.add (this.speedBar =  new a2s.Scrollbar (0, 6, 1, 1, 200));
this.speedBar.addAdjustmentListener (this);
 new a2s.Label ("Steps", 0);
this.stepBar =  new a2s.Scrollbar (0, 40, 1, 1, 300);
this.stepBar.addAdjustmentListener (this);
 new a2s.Label ("Radiation Intensity", 0);
this.strengthBar =  new a2s.Scrollbar (0, 130, 1, 85, 200);
this.strengthBar.addAdjustmentListener (this);
this.add ( new a2s.Label ("Brightness", 0));
this.add (this.brightnessBar =  new a2s.Scrollbar (0, 240, 1, 1, 4000));
this.brightnessBar.addAdjustmentListener (this);
this.add ( new a2s.Label ("Image Resolution", 0));
this.add (this.resolutionBar =  new a2s.Scrollbar (0, res, 2, 20, 240));
this.resolutionBar.addAdjustmentListener (this);
 new a2s.Label ("Scale", 0);
this.scaleBar =  new a2s.Scrollbar (0, 75, 1, 5, 1620);
this.scaleBar.addAdjustmentListener (this);
this.add ( new a2s.Label ("http://www.falstad.com", 0));
try {
var param = this.applet.getParameter ("PAUSE");
if (param != null) this.pause = Integer.parseInt (param);
} catch (e) {
if (Clazz.exceptionOf (e, Exception)) {
} else {
throw e;
}
}
var j;
this.phaseColors =  new Array (400);
for (i = 0; i != 8; i++) for (j = 0; j != 50; j++) {
var ang = Math.atan (j / 50);
this.phaseColors[i * 50 + j] = this.genPhaseColor (i, ang);
}

this.purple =  new java.awt.Color (192, 60, 206);
this.slicerPoints =  Clazz.newIntArray (2, 10, 0);
this.sliceFaces =  Clazz.newDoubleArray (4, 3, 0);
this.rotmatrix =  Clazz.newDoubleArray (9, 0);
this.rotmatrix[0] = this.rotmatrix[4] = this.rotmatrix[8] = 1;
this.rotate (0, -1.5707963267948966);
this.xpoints =  Clazz.newIntArray (4, 0);
this.ypoints =  Clazz.newIntArray (4, 0);
this.setupSimpson ();
this.setupStates ();
this.doSetup ();
this.random =  new java.util.Random ();
this.reinit ();
this.cv.setBackground (java.awt.Color.black);
this.cv.setForeground (java.awt.Color.white);
this.resize (580, 500);
this.handleResize ();
var x = this.getSize ();
var screen = this.getToolkit ().getScreenSize ();
this.setLocation (Clazz.doubleToInt ((screen.width - x.width) / 2), Clazz.doubleToInt ((screen.height - x.height) / 2));
this.show ();
});
Clazz.defineMethod (c$, "setupStates", 
function () {
var maxn = 5;
this.stateCount = Clazz.doubleToInt (maxn * (maxn + 1) * (2 * maxn + 1) / 6);
var i;
this.states =  new Array (this.stateCount);
var n = 1;
var l = 0;
var m = 0;
for (i = 0; i != this.stateCount; i++) {
var bs = this.states[i] = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.BasisState, this, null);
bs.index = i;
bs.elevel = -1 / (2. * n * n);
bs.n = n;
bs.l = l;
bs.m = m;
if (m < l) m++;
 else {
l++;
if (l < n) m = -l;
 else {
n++;
l = m = 0;
}}}
});
Clazz.defineMethod (c$, "getMenuItem", 
function (s) {
var mi =  new a2s.MenuItem (s);
mi.addActionListener (this);
return mi;
}, "~S");
Clazz.defineMethod (c$, "getCheckItem", 
function (s) {
var mi =  new a2s.CheckboxMenuItem (s);
mi.addItemListener (this);
return mi;
}, "~S");
Clazz.defineMethod (c$, "genPhaseColor", 
function (sec, ang) {
ang += sec * 3.141592653589793 / 4;
ang *= 0.954929658551372;
var hsec = Clazz.doubleToInt (ang);
var a2 = ang % 1;
var a3 = 1. - a2;
var c = null;
switch (hsec) {
case 6:
case 0:
c = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.PhaseColor, this, null, 1, a2, 0);
break;
case 1:
c = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.PhaseColor, this, null, a3, 1, 0);
break;
case 2:
c = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.PhaseColor, this, null, 0, 1, a2);
break;
case 3:
c = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.PhaseColor, this, null, 0, a3, 1);
break;
case 4:
c = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.PhaseColor, this, null, a2, 0, 1);
break;
case 5:
c = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.PhaseColor, this, null, 1, 0, a3);
break;
}
return c;
}, "~N,~N");
Clazz.defineMethod (c$, "setupSimpson", 
function () {
this.sampleCount = 15;
this.sampleMult =  Clazz.newIntArray (this.sampleCount, 0);
var i;
for (i = 1; i < this.sampleCount; i += 2) {
this.sampleMult[i] = 4;
this.sampleMult[i + 1] = 2;
}
this.sampleMult[0] = this.sampleMult[this.sampleCount - 1] = 1;
});
Clazz.defineMethod (c$, "handleResize", 
function () {
this.reinit ();
});
Clazz.defineMethod (c$, "reinit", 
function () {
this.setResolution ();
var d = this.winSize = this.cv.getSize ();
if (this.winSize.width == 0) return;
this.dbimage = this.createImage (d.width, d.height);
this.setupDisplay ();
});
Clazz.defineMethod (c$, "createPhasors", 
function () {
this.phasorCount = 0;
var i;
if (this.viewStates == null) return;
var sz = Clazz.doubleToInt (this.viewStates.height / 4);
var x = 0;
var y = this.viewStates.y;
var n = 1;
var l = 0;
var m = 0;
sz = Clazz.doubleToInt (this.viewStates.height / 5);
this.phasorCount = 32;
this.phasors =  new Array (this.phasorCount);
var pct = 0;
for (i = 0; i != this.stateCount; i++) {
if (l < 3) {
var ph = this.phasors[pct] = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.Phasor, this, null, x, y, sz, sz);
pct++;
ph.state = this.states[i];
x += sz;
}if (++m > l) {
x += sz;
l++;
m = -l;
if (l >= n) {
x = 0;
y += sz;
n++;
l = m = 0;
}}}
this.createOrbitals ();
});
Clazz.defineMethod (c$, "setupDisplay", 
function () {
if (this.winSize == null) return;
var potsize = (this.viewPotential == null) ? 50 : this.viewPotential.height;
var statesize = (this.viewStates == null) ? 64 : this.viewStates.height;
this.viewX = this.viewPotential = this.viewStates = null;
this.viewList =  new Array (10);
var i = 0;
if (this.eCheckItem.getState ()) this.viewList[i++] = this.viewPotential = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.View, this, null);
if (this.xCheckItem.getState ()) this.viewList[i++] = this.viewX = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.View, this, null);
this.viewList[i++] = this.viewStates = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.View, this, null);
this.viewCount = i;
var sizenum = this.viewCount;
var toth = this.winSize.height;
if (potsize > 0 && this.viewPotential != null) {
sizenum--;
toth -= potsize;
}if (statesize > 0 && this.viewStates != null) {
sizenum--;
toth -= statesize;
}toth -= 4 * 2 * (this.viewCount - 1);
var cury = 0;
for (i = 0; i != this.viewCount; i++) {
var v = this.viewList[i];
var h = (sizenum == 0) ? toth : Clazz.doubleToInt (toth / sizenum);
if (v === this.viewPotential && potsize > 0) h = potsize;
 else if (v === this.viewStates && statesize > 0) h = statesize;
v.paneY = cury;
if (cury > 0) cury += 4;
v.x = 0;
v.width = this.winSize.width;
v.y = cury;
v.height = h;
cury += h + 4;
}
this.setSubViews ();
});
Clazz.defineMethod (c$, "setSubViews", 
function () {
var i;
this.pixels = null;
if (this.useBufferedImage) {
try {
var biclass = Clazz._4Name ("java.awt.image.BufferedImage");
var dbiclass = Clazz._4Name ("java.awt.image.DataBufferInt");
var rasclass = Clazz._4Name ("java.awt.image.Raster");
var cstr = biclass.getConstructor ( Clazz.newArray (-1, [Number, Number, Number]));
this.memimage = cstr.newInstance ( Clazz.newArray (-1, [ new Integer (this.viewX.width),  new Integer (this.viewX.height),  new Integer (1)]));
var m = biclass.getMethod ("getRaster", null);
var ras = m.invoke (this.memimage, null);
var db = rasclass.getMethod ("getDataBuffer", null).invoke (ras, null);
this.pixels = dbiclass.getMethod ("getData", null).invoke (db, null);
} catch (ee) {
if (Clazz.exceptionOf (ee, Exception)) {
System.out.println ("BufferedImage failed");
} else {
throw ee;
}
}
}if (this.pixels == null) {
this.pixels =  Clazz.newIntArray (this.viewX.width * this.viewX.height, 0);
for (i = 0; i != this.viewX.width * this.viewX.height; i++) this.pixels[i] = 0xFF000000;

this.imageSource =  new java.awt.image.MemoryImageSource (this.viewX.width, this.viewX.height, this.pixels, 0, this.viewX.width);
this.imageSource.setAnimated (true);
this.imageSource.setFullBufferUpdates (true);
this.memimage = this.cv.createImage (this.imageSource);
}var asize = Clazz.doubleToInt (this.min (this.viewX.width, this.viewX.height) / 3);
this.viewAxes =  new java.awt.Rectangle (this.viewX.x + this.winSize.width - asize, this.viewX.y, asize, asize);
this.viewField =  new java.awt.Rectangle (this.viewX.x + this.winSize.width - asize, this.viewX.y + this.viewX.height - asize, asize, asize);
this.createPhasors ();
});
Clazz.defineMethod (c$, "getTermWidth", 
function () {
return 8;
});
Clazz.defineMethod (c$, "rotate", 
function (angle1, angle2) {
var r1cos = Math.cos (angle1);
var r1sin = Math.sin (angle1);
var r2cos = Math.cos (angle2);
var r2sin = Math.sin (angle2);
var rotm2 =  Clazz.newDoubleArray (9, 0);
rotm2[0] = r1cos;
rotm2[1] = -r1sin * r2sin;
rotm2[2] = r2cos * r1sin;
rotm2[3] = 0;
rotm2[4] = r2cos;
rotm2[5] = r2sin;
rotm2[6] = -r1sin;
rotm2[7] = -r1cos * r2sin;
rotm2[8] = r1cos * r2cos;
var rotm1 = this.rotmatrix;
this.rotmatrix =  Clazz.newDoubleArray (9, 0);
var i;
var j;
var k;
for (j = 0; j != 3; j++) for (i = 0; i != 3; i++) {
var v = 0;
for (k = 0; k != 3; k++) v += rotm1[k + j * 3] * rotm2[i + k * 3];

this.rotmatrix[i + j * 3] = v;
}

}, "~N,~N");
Clazz.defineMethod (c$, "max", 
function (a, b) {
return a > b ? a : b;
}, "~N,~N");
Clazz.defineMethod (c$, "min", 
function (a, b) {
return a < b ? a : b;
}, "~N,~N");
Clazz.defineMethod (c$, "setResolution", 
function () {
var og = this.gridSizeX;
this.gridSizeX = this.gridSizeY = (this.resolutionBar.getValue () & -2);
if (og == this.gridSizeX) return;
this.dataSize = this.gridSizeX * 4;
System.out.print ("setResolution " + this.dataSize + " " + this.gridSizeX + "\n");
this.resadj = 50. / this.dataSize;
this.precomputeAll ();
});
Clazz.defineMethod (c$, "computeView", 
function (normmult) {
var i;
var j;
var q = 3.14159265 / this.dataSize;
var color = this.colorCheck.getState ();
for (i = 0; i != this.orbCount; i++) this.orbitals[i].setupFrame (normmult);

var izoom = 1 / this.zoom;
var rotm = this.rotmatrix;
var aratio = this.viewX.width / this.viewX.height;
var xmult = this.dataSize / 2.;
var ymult = this.dataSize / 2.;
var zmult = this.dataSize / 2.;
var aratiox = izoom;
var aratioy = izoom;
if (aratio < 1) aratioy /= aratio;
 else aratiox *= aratio;
var slice = this.sliceChooser.getSelectedIndex ();
var boundRadius2 = 0;
for (i = 0; i != this.orbCount; i++) {
var oo = this.orbitals[i];
var br = oo.getBoundRadius (this.colorMult);
if (br > boundRadius2) boundRadius2 = br;
}
boundRadius2 *= boundRadius2;
for (i = 0; i != this.gridSizeX; i++) for (j = 0; j != this.gridSizeY; j++) {
var camvx0 = (2 * i / this.gridSizeX - 1) * aratiox;
var camvy0 = -(2 * j / this.gridSizeY - 1) * aratioy;
var camx = rotm[2] * com.falstad.AtomTransFrame.viewDistance;
var camy = rotm[5] * com.falstad.AtomTransFrame.viewDistance;
var camz = rotm[8] * com.falstad.AtomTransFrame.viewDistance;
var camvx = rotm[0] * camvx0 + rotm[1] * camvy0 - rotm[2];
var camvy = rotm[3] * camvx0 + rotm[4] * camvy0 - rotm[5];
var camvz = rotm[6] * camvx0 + rotm[7] * camvy0 - rotm[8];
var camnorm = Math.sqrt (camvx0 * camvx0 + camvy0 * camvy0 + 1);
var n;
var simpr = 0;
var simpg = 0;
var simpb = 0;
var a = camvx * camvx + camvy * camvy + camvz * camvz;
var b = 2 * (camvx * camx + camvy * camy + camvz * camz);
var c = camx * camx + camy * camy + camz * camz - boundRadius2;
var discrim = b * b - 4 * a * c;
if (discrim < 0) {
this.fillSquare (i, j, 0, 0, 0);
continue;
}discrim = Math.sqrt (discrim);
var mint = (-b - discrim) / (2 * a);
var maxt = (-b + discrim) / (2 * a);
if (slice != 0) {
var t = -100;
switch (slice) {
case 1:
t = (this.sliceval - camx) / camvx;
break;
case 2:
t = (this.sliceval - camy) / camvy;
break;
case 3:
t = (this.sliceval - camz) / camvz;
break;
}
if (t < mint || t > maxt) {
this.fillSquare (i, j, 0, 0, 0);
continue;
}mint = maxt = t;
}var tstep = (maxt - mint) / (this.sampleCount - 1);
var pathlen = (maxt - mint) * camnorm;
var maxn = this.sampleCount - 1;
n = 1;
var xx = (camx + camvx * mint) * xmult;
var yy = (camy + camvy * mint) * ymult;
var zz = (camz + camvz * mint) * zmult;
if (slice != 0) {
maxn = 1;
n = 0;
pathlen = 2;
if (xx > xmult || yy > ymult || zz > zmult || xx < -xmult || yy < -ymult || zz < -zmult) {
this.fillSquare (i, j, 0, 0, 0);
continue;
}}camvx *= tstep * xmult;
camvy *= tstep * ymult;
camvz *= tstep * zmult;
var dshalf = Clazz.doubleToInt (this.dataSize / 2);
var oi;
for (; n < maxn; n++) {
var r = Math.sqrt (xx * xx + yy * yy + zz * zz);
var costh = zz / r;
var ri = Clazz.doubleToInt (r);
var costhi = Clazz.doubleToInt (costh * dshalf + dshalf);
var fr = 0;
var fi = 0;
this.calcPhiComponent (xx, yy);
for (oi = 0; oi != this.orbCount; oi++) {
var oo = this.orbitals[oi];
oo.computePoint (ri, costhi);
fr += this.funcr;
fi += this.funci;
}
if (color) {
var fv = fr * fr + fi * fi;
fv *= this.sampleMult[n];
var col = this.getPhaseColor (fr, fi);
simpr += col.r * fv;
simpg += col.g * fv;
simpb += col.b * fv;
} else {
var fv = (fr * fr + fi * fi) * this.sampleMult[n];
simpr = simpg = (simpb += fv);
}xx += camvx;
yy += camvy;
zz += camvz;
}
simpr *= pathlen / n;
simpg *= pathlen / n;
simpb *= pathlen / n;
this.fillSquare (i, j, simpr, simpg, simpb);
}

}, "~N");
Clazz.defineMethod (c$, "fillSquare", 
function (i, j, cr, cg, cb) {
var winw = this.viewX.width;
var winh = this.viewX.height;
var x = Clazz.doubleToInt (i * winw / this.gridSizeX);
var y = Clazz.doubleToInt (j * winh / this.gridSizeY);
var x2 = Clazz.doubleToInt ((i + 1) * winw / this.gridSizeX);
var y2 = Clazz.doubleToInt ((j + 1) * winh / this.gridSizeY);
cr *= this.colorMult;
cg *= this.colorMult;
cb *= this.colorMult;
var k;
var l;
if (cr == 0 && cg == 0 && cb == 0) {
var y2l = y2 * this.viewX.width;
for (k = x; k < x2; k++) for (l = y * this.viewX.width; l < y2l; l += this.viewX.width) this.pixels[k + l] = 0xFF000000;


return;
}var fm = this.max (cr, this.max (cg, cb));
if (fm > 255) {
fm /= 255;
cr /= fm;
cg /= fm;
cb /= fm;
}var colval = 0xFF000000 + ((Clazz.floatToInt (cr)) << 16) | ((Clazz.floatToInt (cg)) << 8) | ((Clazz.floatToInt (cb)));
var y2l = y2 * this.viewX.width;
for (k = x; k < x2; k++) for (l = y * this.viewX.width; l < y2l; l += this.viewX.width) this.pixels[k + l] = colval;


}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "getPhaseColor", 
function (x, y) {
var val = 0;
if (x == 0 && y == 0) return this.phaseColors[0];
var offset = 0;
if (y >= 0) {
if (x >= 0) {
if (x >= y) {
offset = 0;
val = y / x;
} else {
offset = 50;
val = 1 - x / y;
}} else {
if (-x <= y) {
offset = 100;
val = -x / y;
} else {
offset = 150;
val = 1 + y / x;
}}} else {
if (x <= 0) {
if (y >= x) {
offset = 200;
val = y / x;
} else {
offset = 250;
val = 1 - x / y;
}} else {
if (-y >= x) {
offset = 300;
val = -x / y;
} else {
offset = 350;
val = 1 + y / x;
}}}return this.phaseColors[offset + Clazz.doubleToInt (val * (49))];
}, "~N,~N");
Clazz.defineMethod (c$, "calcPhiComponent", 
function (x, y) {
var phiSector = 0;
var val = 0;
if (x == 0 && y == 0) {
this.phiIndex = 0;
return;
}if (y >= 0) {
if (x >= 0) {
if (x >= y) {
phiSector = 0;
val = y / x;
} else {
phiSector = 1;
val = 1 - x / y;
}} else {
if (-x <= y) {
phiSector = 2;
val = -x / y;
} else {
phiSector = 3;
val = 1 + y / x;
}}} else {
if (x <= 0) {
if (y >= x) {
phiSector = 4;
val = y / x;
} else {
phiSector = 5;
val = 1 - x / y;
}} else {
if (-y >= x) {
phiSector = 6;
val = -x / y;
} else {
phiSector = 7;
val = 1 + y / x;
}}}this.phiIndex = (phiSector * (this.dataSize + 1)) + Clazz.doubleToInt (val * this.dataSize);
}, "~N,~N");
Clazz.defineMethod (c$, "getScaleRadius", 
function (n) {
var l = 0;
var b0 = -n * n * 2;
var c0 = l * (l + 1) * n * n;
var r0 = .5 * (-b0 + Math.sqrt (b0 * b0 - 4 * c0));
return r0;
}, "~N");
Clazz.defineMethod (c$, "setScale", 
function (n) {
if (this.manualScale || !this.autoZoomItem.getState ()) return;
var outer = this.getScaleRadius (n);
var scaleValue = Clazz.doubleToInt (outer * 3.15);
var oldScaleValue = this.scaleBar.getValue ();
if (oldScaleValue != scaleValue) {
var diff = scaleValue - oldScaleValue;
if (diff < -5 || diff > 5) {
diff = Clazz.doubleToInt (diff / 3);
if (diff < -50) diff = -50;
if (diff > 50) diff = 50;
}var nv = oldScaleValue + diff;
if (!this.animatedZoomItem.getState ()) nv = scaleValue;
this.scaleBar.setValue (nv);
scaleValue = nv;
this.precomputeAll ();
}}, "~N");
Clazz.defineMethod (c$, "precomputeAll", 
function () {
var i;
for (i = 0; i != this.orbCount; i++) {
var orb = this.orbitals[i];
orb.precompute ();
}
});
Clazz.defineMethod (c$, "sign", 
function (x) {
return x < 0 ? -1 : 1;
}, "~N");
Clazz.defineMethod (c$, "updateAtomTrans", 
function (realg) {
var n1 = 1;
var n2 = 1;
switch (this.freqChooser.getSelectedIndex ()) {
case 0:
n1 = 1;
n2 = 2;
break;
case 1:
n1 = 1;
n2 = 3;
break;
case 2:
n1 = 1;
n2 = 4;
break;
case 3:
n1 = 2;
n2 = 3;
break;
case 4:
n1 = 2;
n2 = 4;
break;
case 5:
n1 = 3;
n2 = 4;
break;
}
;var g = null;
if (this.winSize == null || this.winSize.width == 0) return;
g = this.dbimage.getGraphics ();
g.setColor (this.cv.getBackground ());
g.fillRect (0, 0, this.winSize.width, this.winSize.height);
g.setColor (this.cv.getForeground ());
if (this.fontMetrics == null) this.fontMetrics = g.getFontMetrics ();
var allQuiet = false;
var norm = 0;
var normmult = 0;
var normmult2 = 0;
this.normalize ();
var i;
for (i = 0; i != this.stateCount; i++) {
var st = this.states[i];
norm += st.magSquared ();
}
normmult2 = 1 / norm;
if (norm == 0) normmult2 = 0;
normmult = Math.sqrt (normmult2);
this.setScale (n2);
var sliced = this.sliceChooser.getSelectedIndex () != 0;
this.zoom = (sliced) ? 8 : 16.55;
this.colorMult = Math.exp (this.brightnessBar.getValue () / 100.);
this.computeView (normmult);
var j;
var k;
for (i = 1; i != this.viewCount; i++) {
g.setColor (i == this.selectedPaneHandle ? java.awt.Color.yellow : java.awt.Color.gray);
g.drawLine (0, this.viewList[i].paneY, this.winSize.width, this.viewList[i].paneY);
}
if (this.viewPotential != null) {
var ymult = this.viewPotential.height * 1.9;
g.setColor (java.awt.Color.darkGray);
for (i = 1; i != 16; i++) {
var e = -1 / (2. * i * i);
var y = this.viewPotential.y - Clazz.doubleToInt (ymult * e);
g.drawLine (0, y, this.winSize.width, y);
}
var xp = this.getScaler ();
g.setColor (java.awt.Color.white);
var ox = -1;
var oy = -1;
var x;
var floory = this.viewPotential.y + this.viewPotential.height - 1;
for (x = 0; x != this.winSize.width; x++) {
var xx = (x - Clazz.doubleToInt (this.winSize.width / 2)) * xp;
if (xx < 0) xx = -xx;
if (xx < 1e-3) xx = 1e-3;
var dy = -1 / xx;
var y = this.viewPotential.y - Clazz.doubleToInt (ymult * dy);
if (y > floory) {
if (ox == -1) continue;
g.drawLine (ox, oy, ox, floory);
ox = -1;
continue;
}if (ox == -1 && x > 0) {
g.drawLine (x, floory, x, y);
ox = x;
oy = y;
continue;
}if (ox != -1) g.drawLine (ox, oy, x, y);
ox = x;
oy = y;
}
if (norm != 0) {
var expecte = 0;
for (i = 0; i != this.stateCount; i++) {
var st = this.states[i];
var prob = st.magSquared () * normmult2;
expecte += prob * st.elevel;
}
var y = this.viewPotential.y - Clazz.doubleToInt (ymult * expecte);
g.setColor (java.awt.Color.red);
g.drawLine (0, y, this.winSize.width, y);
}if (this.selectedState != null && !this.dragging) {
g.setColor (java.awt.Color.yellow);
var y = this.viewPotential.y - Clazz.doubleToInt (ymult * this.selectedState.elevel);
g.drawLine (0, y, this.winSize.width, y);
}}if (this.imageSource != null) this.imageSource.newPixels ();
g.drawImage (this.memimage, this.viewX.x, this.viewX.y, null);
g.setColor (java.awt.Color.white);
if (sliced) this.drawCube (g, false);
if (this.axesItem.getState ()) this.drawAxes (g);
g.setColor (java.awt.Color.yellow);
if (this.selectedState != null) this.centerString (g, this.selectedState.getText (), this.viewX.y + this.viewX.height - 5);
 else if (this.dimensionsItem.getState ()) {
var xp = this.getScaler ();
var w = this.winSize.width * xp * 52.9463;
var lambda = 91.1763 / (1. / (n1 * n1) - 1. / (n2 * n2)) + .5;
var period = 3.3356 * lambda;
var expecte = 0;
if (norm != 0) {
for (i = 0; i != this.stateCount; i++) {
var st = this.states[i];
var prob = st.magSquared () * normmult2;
expecte += prob * st.elevel;
}
}var energy = 13.6 * 2 * expecte;
energy = (Clazz.doubleToInt (energy * 10)) / 10.;
this.centerString (g, "Screen width = " + Clazz.doubleToInt (w) + " pm, " + "Wavelength = " + Clazz.doubleToInt (lambda) + " nm", this.viewX.y + this.viewX.height - 25);
this.centerString (g, "Period = " + Clazz.doubleToInt (period) + " attoseconds, " + "<E> = " + energy + " eV", this.viewX.y + this.viewX.height - 5);
}if (this.viewStates != null) {
this.drawPhasors (g, this.viewStates);
this.drawTransitions (g, this.viewStates, n1, n2);
}var steprate = 24 * this.speedBar.getValue ();
var stopped = (this.stoppedCheck.getState () || this.dragging);
if (stopped) this.lastFrameTime = 0;
 else allQuiet = false;
if (this.newcoef == null) {
this.newcoef =  new Array (this.stateCount);
for (j = 0; j != this.stateCount; j++) this.newcoef[j] =  new com.falstad.Complex ();

}var tadd = Math.exp (this.stepBar.getValue () / 20.) * (0.02);
var strengthMul = Math.exp (this.strengthBar.getValue () / 20.) / (409500.0);
this.freq = this.getState (n1, 0, 0).elevel - this.getState (n2, 0, 0).elevel;
var dipoleArr = null;
var circular = false;
var cwmult = 1;
switch (this.dirChooser.getSelectedIndex ()) {
case 0:
dipoleArr = this.dipoleOpX;
break;
case 1:
dipoleArr = this.dipoleOpY;
break;
case 2:
dipoleArr = this.dipoleOpZ;
break;
case 3:
circular = true;
cwmult = -1;
break;
case 4:
circular = true;
break;
}
var mul =  new com.falstad.Complex ();
var newval =  new com.falstad.Complex ();
var baseEnergy = this.getState (n1, 0, 0).elevel - .01;
var iter;
for (iter = 1; ; iter++) {
if (stopped) break;
var mul1 = strengthMul * Math.sin (this.t * this.freq) * tadd;
var mul2 = strengthMul * Math.cos (this.t * this.freq) * tadd;
this.freqPhase = (this.t * this.freq) % (6.283185307179586);
for (j = 0; j != this.stateCount; j++) {
var st = this.states[j];
if (this.restrictItem.getState () && st.n != n1 && st.n != n2) {
this.newcoef[j].setRe (0);
continue;
}newval.set (st);
for (k = 0; k != this.stateCount; k++) {
var sk = this.states[k];
if (sk.n != n1 && sk.n != n2) continue;
if (circular) {
var dpx = this.dipoleOp (j, k, this.dipoleOpX);
var dpy = -cwmult * this.dipoleOp (j, k, this.dipoleOpY);
mul.setReIm (mul2 * dpx, mul1 * dpy);
} else {
var dp = mul1 * this.dipoleOp (j, k, dipoleArr);
if (dipoleArr === this.dipoleOpY) mul.setReIm (0, -dp);
 else mul.setRe (dp);
}mul.multReIm (0, 1);
mul.mult (sk);
newval.addQuick (mul.re, mul.im);
}
var ang = -(st.elevel - baseEnergy) * tadd;
var angr = Math.cos (ang);
var angi = Math.sin (ang);
newval.multReIm (angr, angi);
if (newval.mag > 1e-6) this.newcoef[j].set (newval);
 else this.newcoef[j].setRe (0);
}
for (j = 0; j != this.stateCount; j++) this.states[j].set (this.newcoef[j]);

this.t += tadd;
var tm = System.currentTimeMillis ();
if (iter * 1000 >= steprate * (tm - this.lastFrameTime) || (tm - this.lastFrameTime > 500)) break;
}
var ex = 0;
var ey = 0;
var ez = 0;
switch (this.dirChooser.getSelectedIndex ()) {
case 0:
ex = Math.sin (this.t * this.freq);
break;
case 1:
ey = Math.sin (this.t * this.freq);
break;
case 2:
ez = Math.sin (this.t * this.freq);
break;
case 3:
case 4:
ex = Math.cos (this.t * this.freq);
ey = cwmult * Math.sin (this.t * this.freq);
break;
}
this.normalize ();
this.createOrbitals ();
var q = Clazz.doubleToInt (20 * Math.sin (this.t * this.freq));
g.setColor (java.awt.Color.darkGray);
var da = .5;
this.map3d (0, 0, 0, this.xpoints, this.ypoints, 0, this.viewField);
this.map3d (da, 0, 0, this.xpoints, this.ypoints, 1, this.viewField);
g.drawLine (this.xpoints[0], this.ypoints[0], this.xpoints[1], this.ypoints[1]);
this.map3d (0, da, 0, this.xpoints, this.ypoints, 1, this.viewField);
g.drawLine (this.xpoints[0], this.ypoints[0], this.xpoints[1], this.ypoints[1]);
this.map3d (0, 0, da, this.xpoints, this.ypoints, 1, this.viewField);
g.drawLine (this.xpoints[0], this.ypoints[0], this.xpoints[1], this.ypoints[1]);
g.setColor (java.awt.Color.white);
this.map3d (ex * da, ey * da, ez * da, this.xpoints, this.ypoints, 1, this.viewField);
this.drawArrow (g, null, this.xpoints[0], this.ypoints[0], this.xpoints[1], this.ypoints[1]);
if (!this.dimensionsItem.getState ()) g.drawString ("qE", this.viewField.x + Clazz.doubleToInt ((this.viewField.width - this.fontMetrics.stringWidth ("qE")) / 2), this.viewField.y + this.viewField.height - 10);
realg.drawImage (this.dbimage, 0, 0, this);
this.lastFrameTime = System.currentTimeMillis ();
if (!allQuiet) this.cv.repaint (this.pause);
}, "java.awt.Graphics");
Clazz.defineMethod (c$, "dipoleOp", 
function (a, b, arr) {
var sa = this.states[a];
var sb = this.states[b];
if (sa.n == sb.n) return 0;
if (sa.l > 2 || sb.l > 2) return 0;
if (sa.n > 5 || sb.n > 5) return 0;
var san = this.getDipoleStateNum (sa);
var sbn = this.getDipoleStateNum (sb);
return arr[san * 32 + sbn];
}, "~N,~N,~A");
Clazz.defineMethod (c$, "getDipoleStateNum", 
function (bs) {
if (bs.l == 0) return bs.n - 1;
if (bs.l == 1) return 5 + (bs.n - 2) * 3 + bs.m + 1;
return 17 + (bs.n - 3) * 5 + bs.m + 2;
}, "com.falstad.AtomTransFrame.BasisState");
Clazz.defineMethod (c$, "getScaler", 
function () {
var scalex = this.viewX.width * this.zoom / 2;
var scaley = this.viewX.height * this.zoom / 2;
var aratio = this.viewX.width / this.viewX.height;
if (aratio < 1) scaley *= aratio;
 else scalex /= aratio;
var xp = 2 * scalex / com.falstad.AtomTransFrame.viewDistance;
var mult = this.scaleBar.getValue () / 50.;
xp /= 50 * mult;
xp = 1 / xp;
return xp;
});
Clazz.defineMethod (c$, "centerString", 
function (g, str, ypos) {
g.drawString (str, Clazz.doubleToInt ((this.winSize.width - this.fontMetrics.stringWidth (str)) / 2), ypos);
}, "java.awt.Graphics,~S,~N");
Clazz.defineMethod (c$, "visibleFace", 
function (nx, ny, nz) {
var viewx = com.falstad.AtomTransFrame.viewDistance * this.rotmatrix[2];
var viewy = com.falstad.AtomTransFrame.viewDistance * this.rotmatrix[5];
var viewz = com.falstad.AtomTransFrame.viewDistance * this.rotmatrix[8];
return (nx - viewx) * nx + (ny - viewy) * ny + (nz - viewz) * nz < 0;
}, "~N,~N,~N");
Clazz.defineMethod (c$, "drawPhasors", 
function (g, v) {
var i;
for (i = 0; i != this.phasorCount; i++) {
var ph = this.phasors[i];
var st = ph.state;
var ss = ph.width;
var ss2 = Clazz.doubleToInt (ss / 2);
var x = ph.x + ss2;
var y = ph.y + ss2;
var yel = (this.selectedState === st);
g.setColor (yel ? java.awt.Color.yellow : st.mag == 0 ? this.gray2 : java.awt.Color.white);
g.drawOval (x - ss2, y - ss2, ss, ss);
var xa = Clazz.doubleToInt (st.re * ss2);
var ya = Clazz.doubleToInt (-st.im * ss2);
g.drawLine (x, y, x + xa, y + ya);
g.drawLine (x + xa - 1, y + ya, x + xa + 1, y + ya);
g.drawLine (x + xa, y + ya - 1, x + xa, y + ya + 1);
}
}, "java.awt.Graphics,com.falstad.AtomTransFrame.View");
Clazz.defineMethod (c$, "drawTransitions", 
function (g, v, n1, n2) {
var i;
var offx = Clazz.doubleToInt (this.winSize.width / 2);
if (this.phasors[0].width * 11 >= offx) return;
var mul =  new com.falstad.Complex ();
var newval =  new com.falstad.Complex ();
var circular = false;
var cwmult = 1;
var dipoleArr = null;
switch (this.dirChooser.getSelectedIndex ()) {
case 0:
dipoleArr = this.dipoleOpX;
break;
case 1:
dipoleArr = this.dipoleOpY;
break;
case 2:
dipoleArr = this.dipoleOpZ;
break;
case 3:
circular = true;
cwmult = -1;
break;
case 4:
circular = true;
break;
}
for (i = 0; i != this.phasorCount; i++) {
var ph = this.phasors[i];
var st = ph.state;
var ss = ph.width;
var ss2 = Clazz.doubleToInt (ss / 2);
var x = ph.x + ss2 + offx;
var y = ph.y + ss2;
var yel = (this.selectedState === st);
g.setColor (yel ? java.awt.Color.yellow : st.mag == 0 ? this.gray2 : java.awt.Color.white);
var dip = 0;
var j;
newval.setRe (0);
for (j = 0; j != this.stateCount; j++) {
var sj = this.states[j];
var ii = st.index;
if (circular) {
var dpx = this.dipoleOp (ii, j, this.dipoleOpX);
var dpy = -cwmult * this.dipoleOp (ii, j, this.dipoleOpY);
mul.setRe (dpx + dpy);
} else {
var dp = this.dipoleOp (ii, j, dipoleArr);
if (dipoleArr === this.dipoleOpY) mul.setReIm (0, -dp);
 else mul.setRe (dp);
}mul.multReIm (0, 1);
mul.mult (sj);
newval.addQuick (mul.re, mul.im);
}
var nvn = (newval.re * newval.re + newval.im * newval.im) * 1e4 + 1e-8;
nvn = Math.sqrt (nvn);
var c;
c = Clazz.doubleToInt (nvn * 3.5);
if (c > 255) c = 255;
if (c < 0) c = 0;
g.setColor ( new java.awt.Color (0, 0, c / 255));
g.fillOval (x - ss2, y - ss2, ss, ss);
g.setColor (st.n == n1 || st.n == n2 ? this.purple : this.gray2);
g.drawOval (x - ss2, y - ss2, ss, ss);
}
}, "java.awt.Graphics,com.falstad.AtomTransFrame.View,~N,~N");
Clazz.defineMethod (c$, "drawFunction", 
function (g, view, pos, fr, count, pad, fromZero) {
var i;
var expectx = 0;
var expectx2 = 0;
var maxsq = 0;
var tot = 0;
var vw = Clazz.doubleToInt (this.winSize.width / 3);
var vw2 = Clazz.doubleToInt (vw * 4 / 5);
var mid_x = (fromZero) ? (Clazz.doubleToInt (vw2 / (count - 1))) : Clazz.doubleToInt (vw2 * (Clazz.doubleToInt (count / 2)) / (count - 1));
var zero = mid_x;
mid_x += vw * pos;
for (i = 0; i != count; i++) {
var x = Clazz.doubleToInt (vw2 * i / (count - 1));
var ii = i;
var dr = fr[ii];
var dy = dr * dr;
if (dy > maxsq) maxsq = dy;
var dev = x - zero;
expectx += dy * dev;
expectx2 += dy * dev * dev;
tot += dy;
}
zero = mid_x;
expectx /= tot;
expectx2 /= tot;
var maxnm = Math.sqrt (maxsq);
var uncert = Math.sqrt (expectx2 - expectx * expectx);
var ox = -1;
var oy = 0;
var bestscale = 1 / maxnm;
view.scale = bestscale;
if (view.scale > 1e8) view.scale = 1e8;
g.setColor (java.awt.Color.gray);
g.drawLine (mid_x, view.y, mid_x, view.y + view.height);
var ymult2 = .90 * view.height;
var mid_y = view.y + Clazz.doubleToInt (view.height / 2) + Clazz.doubleToInt (Clazz.doubleToInt (ymult2) / 2);
var mult = ymult2 * view.scale;
g.setColor (java.awt.Color.white);
ox = -1;
for (i = 0; i != count; i++) {
var x = Clazz.doubleToInt (vw2 * i / (count - 1)) + vw * pos;
var ii = i;
var y = mid_y - Clazz.doubleToInt (mult * fr[ii]);
if ((i % pad) == 1) {
g.setColor (java.awt.Color.gray);
g.drawLine (x, mid_y, x, mid_y + 4);
g.setColor (java.awt.Color.white);
}if (ox != -1) g.drawLine (ox, oy, x, y);
ox = x;
oy = y;
}
if (maxsq > 0) {
expectx += zero + .5;
g.setColor (java.awt.Color.red);
g.drawLine (Clazz.doubleToInt (expectx), view.y, Clazz.doubleToInt (expectx), view.y + view.height);
}}, "java.awt.Graphics,com.falstad.AtomTransFrame.View,~N,~A,~N,~N,~B");
Clazz.defineMethod (c$, "drawCube", 
function (g, drawAll) {
var i;
var slice = this.sliceChooser.getSelectedIndex ();
var sp = 0;
for (i = 0; i != 6; i++) {
var nx = (i == 0) ? -1 : (i == 1) ? 1 : 0;
var ny = (i == 2) ? -1 : (i == 3) ? 1 : 0;
var nz = (i == 4) ? -1 : (i == 5) ? 1 : 0;
if (!drawAll && !this.visibleFace (nx, ny, nz)) continue;
var pts;
pts =  Clazz.newDoubleArray (3, 0);
var n;
for (n = 0; n != 4; n++) {
this.computeFace (i, n, pts);
this.map3d (pts[0], pts[1], pts[2], this.xpoints, this.ypoints, n, this.viewX);
}
g.setColor (java.awt.Color.gray);
g.drawPolygon (this.xpoints, this.ypoints, 4);
if (slice != 0 && Clazz.doubleToInt (i / 2) != slice - 1) {
if (this.selectedSlice) g.setColor (java.awt.Color.yellow);
var coord1 = (slice == 1) ? 1 : 0;
var coord2 = (slice == 3) ? 1 : 2;
this.computeFace (i, 0, pts);
pts[slice - 1] = this.sliceval;
this.map3d (pts[0], pts[1], pts[2], this.slicerPoints[0], this.slicerPoints[1], sp, this.viewX);
this.computeFace (i, 2, pts);
pts[slice - 1] = this.sliceval;
this.map3d (pts[0], pts[1], pts[2], this.slicerPoints[0], this.slicerPoints[1], sp + 1, this.viewX);
g.drawLine (this.slicerPoints[0][sp], this.slicerPoints[1][sp], this.slicerPoints[0][sp + 1], this.slicerPoints[1][sp + 1]);
this.sliceFaces[Clazz.doubleToInt (sp / 2)][0] = nx;
this.sliceFaces[Clazz.doubleToInt (sp / 2)][1] = ny;
this.sliceFaces[Clazz.doubleToInt (sp / 2)][2] = nz;
sp += 2;
}}
this.sliceFaceCount = sp;
}, "java.awt.Graphics,~B");
Clazz.defineMethod (c$, "computeFace", 
function (b, n, pts) {
var a = b >> 1;
pts[a] = ((b & 1) == 0) ? -1 : 1;
var i;
for (i = 0; i != 3; i++) {
if (i == a) continue;
pts[i] = (((n >> 1) ^ (n & 1)) == 0) ? -1 : 1;
n >>= 1;
}
}, "~N,~N,~A");
Clazz.defineMethod (c$, "drawAxes", 
function (g) {
g.setColor (java.awt.Color.white);
var d = .5;
this.map3d (0, 0, 0, this.xpoints, this.ypoints, 0, this.viewAxes);
this.map3d (d, 0, 0, this.xpoints, this.ypoints, 1, this.viewAxes);
this.drawArrow (g, "x", this.xpoints[0], this.ypoints[0], this.xpoints[1], this.ypoints[1]);
this.map3d (0, d, 0, this.xpoints, this.ypoints, 1, this.viewAxes);
this.drawArrow (g, "y", this.xpoints[0], this.ypoints[0], this.xpoints[1], this.ypoints[1]);
this.map3d (0, 0, d, this.xpoints, this.ypoints, 1, this.viewAxes);
this.drawArrow (g, "z", this.xpoints[0], this.ypoints[0], this.xpoints[1], this.ypoints[1]);
}, "java.awt.Graphics");
Clazz.defineMethod (c$, "drawArrow", 
function (g, text, x1, y1, x2, y2) {
this.drawArrow (g, text, x1, y1, x2, y2, 5);
}, "java.awt.Graphics,~S,~N,~N,~N,~N");
Clazz.defineMethod (c$, "drawArrow", 
function (g, text, x1, y1, x2, y2, as) {
g.drawLine (x1, y1, x2, y2);
var l = Math.sqrt ((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
if (l > Clazz.doubleToInt (as / 2)) {
var hatx = (x2 - x1) / l;
var haty = (y2 - y1) / l;
g.drawLine (x2, y2, Clazz.doubleToInt (haty * as - hatx * as + x2), Clazz.doubleToInt (-hatx * as - haty * as + y2));
g.drawLine (x2, y2, Clazz.doubleToInt (-haty * as - hatx * as + x2), Clazz.doubleToInt (hatx * as - haty * as + y2));
if (text != null) g.drawString (text, Clazz.doubleToInt (x2 + hatx * 10), Clazz.doubleToInt (y2 + haty * 10));
}}, "java.awt.Graphics,~S,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "map3d", 
function (x, y, z, xpoints, ypoints, pt, v) {
var rotm = this.rotmatrix;
var realx = x * rotm[0] + y * rotm[3] + z * rotm[6];
var realy = x * rotm[1] + y * rotm[4] + z * rotm[7];
var realz = com.falstad.AtomTransFrame.viewDistance - (x * rotm[2] + y * rotm[5] + z * rotm[8]);
var scalex = v.width * this.zoom / 2;
var scaley = v.height * this.zoom / 2;
var aratio = v.width / v.height;
if (aratio < 1) scaley *= aratio;
 else scalex /= aratio;
xpoints[pt] = v.x + Clazz.doubleToInt (v.width / 2) + Clazz.doubleToInt (scalex * realx / realz);
ypoints[pt] = v.y + Clazz.doubleToInt (v.height / 2) - Clazz.doubleToInt (scaley * realy / realz);
}, "~N,~N,~N,~A,~A,~N,java.awt.Rectangle");
Clazz.defineMethod (c$, "unmap3d", 
function (x3, x, y, pn, pp) {
var scalex = this.viewX.width * this.zoom / 2;
var scaley = this.viewX.height * this.zoom / 2;
var aratio = this.viewX.width / this.viewX.height;
if (aratio < 1) scaley *= aratio;
 else scalex /= aratio;
var vx = (x - (this.viewX.x + Clazz.doubleToInt (this.viewX.width / 2))) / scalex;
var vy = -(y - (this.viewX.y + Clazz.doubleToInt (this.viewX.height / 2))) / scaley;
var rotm = this.rotmatrix;
var mx = com.falstad.AtomTransFrame.viewDistance * rotm[2];
var my = com.falstad.AtomTransFrame.viewDistance * rotm[5];
var mz = com.falstad.AtomTransFrame.viewDistance * rotm[8];
var mvx = (vx * rotm[0] + vy * rotm[1] - rotm[2]);
var mvy = (vx * rotm[3] + vy * rotm[4] - rotm[5]);
var mvz = (vx * rotm[6] + vy * rotm[7] - rotm[8]);
var t = ((pp[0] - mx) * pn[0] + (pp[1] - my) * pn[1] + (pp[2] - mz) * pn[2]) / (pn[0] * mvx + pn[1] * mvy + pn[2] * mvz);
x3[0] = mx + mvx * t;
x3[1] = my + mvy * t;
x3[2] = mz + mvz * t;
}, "~A,~N,~N,~A,~A");
Clazz.overrideMethod (c$, "componentHidden", 
function (e) {
}, "java.awt.event.ComponentEvent");
Clazz.overrideMethod (c$, "componentMoved", 
function (e) {
}, "java.awt.event.ComponentEvent");
Clazz.overrideMethod (c$, "componentShown", 
function (e) {
this.cv.repaint ();
}, "java.awt.event.ComponentEvent");
Clazz.overrideMethod (c$, "componentResized", 
function (e) {
this.handleResize ();
this.cv.repaint (this.pause);
}, "java.awt.event.ComponentEvent");
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
if (e.getSource () === this.exitItem) {
this.applet.destroyFrame ();
return;
}this.cv.repaint ();
}, "java.awt.event.ActionEvent");
Clazz.overrideMethod (c$, "adjustmentValueChanged", 
function (e) {
if (e.getSource () === this.brightnessBar) {
var mult = Math.exp (this.brightnessBar.getValue () / 100.);
this.userBrightMult = mult / this.bestBrightness;
}if (e.getSource () === this.resolutionBar) this.setResolution ();
this.setupSimpson ();
this.cv.repaint (this.pause);
}, "java.awt.event.AdjustmentEvent");
Clazz.overrideMethod (c$, "mouseDragged", 
function (e) {
this.dragging = true;
this.edit (e);
this.dragX = e.getX ();
this.dragY = e.getY ();
}, "java.awt.event.MouseEvent");
Clazz.defineMethod (c$, "csInRange", 
function (x, xa, xb) {
if (xa < xb) return x >= xa - 5 && x <= xb + 5;
return x >= xb - 5 && x <= xa + 5;
}, "~N,~N,~N");
Clazz.defineMethod (c$, "checkSlice", 
function (x, y) {
if (this.sliceChooser.getSelectedIndex () == 0) {
this.selectedSlice = false;
return;
}var n;
this.selectedSlice = false;
for (n = 0; n != this.sliceFaceCount; n += 2) {
var xa = this.slicerPoints[0][n];
var xb = this.slicerPoints[0][n + 1];
var ya = this.slicerPoints[1][n];
var yb = this.slicerPoints[1][n + 1];
if (!this.csInRange (x, xa, xb) || !this.csInRange (y, ya, yb)) continue;
var d;
if (xa == xb) d = Math.abs (x - xa);
 else {
var b = (yb - ya) / (xb - xa);
var a = ya - b * xa;
var d1 = y - (a + b * x);
if (d1 < 0) d1 = -d1;
d = d1 / Math.sqrt (1 + b * b);
}if (d < 6) {
this.selectedSlice = true;
this.sliceFace = this.sliceFaces[Clazz.doubleToInt (n / 2)];
break;
}}
}, "~N,~N");
Clazz.overrideMethod (c$, "mouseMoved", 
function (e) {
if (this.dragging) return;
var x = e.getX ();
var y = e.getY ();
this.dragX = x;
this.dragY = y;
var oldsph = this.selectedPaneHandle;
var olds = this.selection;
var oldss = this.selectedState;
this.selectedPaneHandle = -1;
this.selection = 0;
this.selectedState = null;
var i;
for (i = 1; i != this.viewCount; i++) {
var dy = y - this.viewList[i].paneY;
if (dy >= -3 && dy <= 3) {
this.selectedPaneHandle = i;
this.selection = 4;
}}
if (this.viewX != null && this.viewX.inside (x, y)) {
this.selection = 2;
this.checkSlice (e.getX (), e.getY ());
} else if (this.viewPotential.contains (x, y)) {
this.selection = 1;
} else if (this.viewStates != null && this.viewStates.inside (x, y)) this.findPhasor (this.viewStates, x, y);
if (oldsph != this.selectedPaneHandle || olds != this.selection || oldss !== this.selectedState) this.cv.repaint (this.pause);
}, "java.awt.event.MouseEvent");
Clazz.defineMethod (c$, "findPhasor", 
function (v, x, y) {
var i;
for (i = 0; i != this.phasorCount; i++) {
if (!this.phasors[i].inside (x, y)) continue;
this.selectedPhasor = this.phasors[i];
this.selectedState = this.selectedPhasor.state;
this.selection = 3;
break;
}
}, "com.falstad.AtomTransFrame.View,~N,~N");
Clazz.overrideMethod (c$, "mouseClicked", 
function (e) {
if (this.selection == 3) this.editMagClick ();
if (e.getClickCount () == 2 && this.selectedState != null) this.enterSelectedState ();
}, "java.awt.event.MouseEvent");
Clazz.defineMethod (c$, "enterSelectedState", 
function () {
var i;
for (i = 0; i != this.stateCount; i++) if (this.states[i] !== this.selectedState) this.states[i].setRe (0);

this.selectedState.convertBasisToDerived ();
this.selectedState.setRe (1);
this.selectedState.convertDerivedToBasis ();
this.createOrbitals ();
this.cv.repaint (this.pause);
});
Clazz.overrideMethod (c$, "mouseEntered", 
function (e) {
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mouseExited", 
function (e) {
if (!this.dragging && this.selection != 0) {
this.selectedPaneHandle = -1;
this.selectedState = null;
this.selectedPhasor = null;
this.selection = 0;
this.cv.repaint (this.pause);
}}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mousePressed", 
function (e) {
if ((e.getModifiers () & 16) == 0) return;
this.dragX = this.dragStartX = e.getX ();
this.dragY = this.dragStartY = e.getY ();
this.dragZoomStart = this.zoom;
this.dragging = true;
this.edit (e);
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mouseReleased", 
function (e) {
if (this.dragging) this.cv.repaint ();
this.dragging = false;
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "itemStateChanged", 
function (e) {
if (Clazz.instanceOf (e.getItemSelectable (), a2s.CheckboxMenuItem)) {
this.setupDisplay ();
this.cv.repaint (this.pause);
return;
}if (e.getItemSelectable () === this.setupChooser) this.doSetup ();
this.cv.repaint (this.pause);
}, "java.awt.event.ItemEvent");
Clazz.defineMethod (c$, "handleEvent", 
function (ev) {
if (ev.id == 201) {
this.destroyFrame ();
return true;
}return Clazz.superCall (this, com.falstad.AtomTransFrame, "handleEvent", [ev]);
}, "java.awt.Event");
Clazz.defineMethod (c$, "destroyFrame", 
function () {
if (this.applet == null) this.dispose ();
 else this.applet.destroyFrame ();
});
Clazz.defineMethod (c$, "edit", 
function (e) {
if (this.selection == 0) return;
var x = e.getX ();
var y = e.getY ();
switch (this.selection) {
case 4:
this.editHandle (y);
break;
case 3:
this.editMag (x, y);
break;
case 1:
break;
case 2:
this.editX (x, y);
break;
}
}, "java.awt.event.MouseEvent");
Clazz.defineMethod (c$, "editHandle", 
function (y) {
var dy = y - this.viewList[this.selectedPaneHandle].paneY;
var upper = this.viewList[this.selectedPaneHandle - 1];
var lower = this.viewList[this.selectedPaneHandle];
var minheight = 10;
if (upper.height + dy < minheight || lower.height - dy < minheight) return;
upper.height += dy;
lower.height -= dy;
lower.y += dy;
lower.paneY += dy;
this.cv.repaint (this.pause);
this.setSubViews ();
}, "~N");
Clazz.defineMethod (c$, "editX", 
function (x, y) {
var mode = 0;
if (this.selectedSlice) mode = 1;
if (mode == 0) {
var xo = this.dragX - x;
var yo = this.dragY - y;
this.rotate (xo / 40., -yo / 40.);
this.cv.repaint (this.pause);
} else if (mode == 1) {
var x3 =  Clazz.newDoubleArray (3, 0);
this.unmap3d (x3, x, y, this.sliceFace, this.sliceFace);
switch (this.sliceChooser.getSelectedIndex ()) {
case 1:
this.sliceval = x3[0];
break;
case 2:
this.sliceval = x3[1];
break;
case 3:
this.sliceval = x3[2];
break;
}
if (this.sliceval < -0.99) this.sliceval = -0.99;
if (this.sliceval > .99) this.sliceval = .99;
this.cv.repaint (this.pause);
}}, "~N,~N");
Clazz.defineMethod (c$, "editMag", 
function (x, y) {
if (this.selectedPhasor == null) return;
var stateSize = this.selectedPhasor.width;
var ss2 = Clazz.doubleToInt (stateSize / 2);
var x0 = this.selectedPhasor.x + ss2;
var y0 = this.selectedPhasor.y + ss2;
x -= x0;
y -= y0;
var mag = Math.sqrt (x * x + y * y) / ss2;
var ang = Math.atan2 (-y, x);
if (mag > 10) mag = 0;
if (mag > 1) mag = 1;
this.selectedState.setMagPhase (mag, ang);
this.cv.repaint (this.pause);
this.createOrbitals ();
}, "~N,~N");
Clazz.defineMethod (c$, "editMagClick", 
function () {
if (this.selectedState == null) return;
if (this.magDragStart < .5) this.selectedState.setReIm (1, 0);
 else this.selectedState.setRe (0);
this.cv.repaint (this.pause);
this.createOrbitals ();
});
Clazz.defineMethod (c$, "createOrbitals", 
function () {
var i;
var newOrbCount = 0;
var newOrbitals = false;
var magmin = 0;
for (i = 0; i != this.stateCount; i++) {
var st = this.states[i];
if (st.m == 0) {
if (st.mag > magmin) {
newOrbCount++;
if (st.orb == null) newOrbitals = true;
} else if (st.orb != null) newOrbitals = true;
} else if (st.m > 0) {
if (st.mag > magmin || this.getState (st.n, st.l, -st.m).mag > magmin) {
newOrbCount++;
if (st.orb == null) newOrbitals = true;
} else if (st.orb != null) newOrbitals = true;
}}
if (!newOrbitals) return;
this.orbCount = newOrbCount;
this.orbitals =  new Array (this.orbCount);
var oi = 0;
for (i = 0; i != this.stateCount; i++) {
var st = this.states[i];
if ((st.m == 0 && st.mag > magmin) || (st.m > 0 && (st.mag > magmin || this.getState (st.n, st.l, -st.m).mag > magmin))) {
if (st.orb == null) {
var orb;
if (st.l == 0) orb = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.SOrbital, this, null, st);
 else if (st.m == 0) orb = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.MZeroOrbital, this, null, st);
 else orb = Clazz.innerTypeInstance (com.falstad.AtomTransFrame.PairedOrbital, this, null, st);
orb.precompute ();
st.orb = orb;
}this.orbitals[oi++] = st.orb;
} else st.orb = null;
}
});
Clazz.defineMethod (c$, "doClear", 
function () {
var x;
for (x = 0; x != this.stateCount; x++) this.states[x].setRe (0);

});
Clazz.defineMethod (c$, "normalize", 
function () {
var norm = 0;
var i;
for (i = 0; i != this.stateCount; i++) norm += this.states[i].magSquared ();

if (norm == 0) return;
var normmult = 1 / Math.sqrt (norm);
for (i = 0; i != this.stateCount; i++) this.states[i].multRe (normmult);

this.cv.repaint (this.pause);
});
Clazz.defineMethod (c$, "maximize", 
function () {
var i;
var maxm = 0;
for (i = 0; i != this.stateCount; i++) if (this.states[i].mag > maxm) maxm = this.states[i].mag;

if (maxm == 0) return;
for (i = 0; i != this.stateCount; i++) this.states[i].multRe (1 / maxm);

this.cv.repaint (this.pause);
});
Clazz.defineMethod (c$, "getState", 
function (n, l, m) {
var pre_n = n - 1;
var pre_n_add = Clazz.doubleToInt (pre_n * (pre_n + 1) * (2 * pre_n + 1) / 6);
var pre_l_add = l * l;
return this.states[pre_n_add + pre_l_add + l + m];
}, "~N,~N,~N");
Clazz.defineMethod (c$, "getStateIndex", 
function (n, l, m) {
var pre_n = n - 1;
var pre_n_add = Clazz.doubleToInt (pre_n * (pre_n + 1) * (2 * pre_n + 1) / 6);
var pre_l_add = l * l;
return pre_n_add + pre_l_add + l + m;
}, "~N,~N,~N");
Clazz.defineMethod (c$, "setBrightness", 
function (normmult) {
var i;
var avg = 0;
var totn = 0;
var minavg = 1e30;
for (i = 0; i != this.orbCount; i++) {
var orb = this.orbitals[i];
var as = orb.getBrightness ();
if (as < minavg) minavg = as;
var st = orb.state;
var n = st.magSquared () * normmult;
if (orb.state.m != 0) n += this.getState (st.n, st.l, -st.m).magSquared () * normmult;
totn += n;
avg += n * as;
}
this.bestBrightness = 113.9 / (Math.sqrt (minavg) * totn);
var mult = this.bestBrightness * this.userBrightMult;
var bvalue = Clazz.doubleToInt (Math.log (mult) * 100.);
this.brightnessBar.setValue (bvalue);
}, "~N");
Clazz.defineMethod (c$, "plgndr", 
function (l, m, x) {
var fact;
var pll = 0;
var pmm;
var pmmp1;
var somx2;
var i;
var ll;
if (m < 0 || m > l || Math.abs (x) > 1.0) {
System.out.print ("bad arguments in plgndr\n");
}pmm = 1.0;
if (m > 0) {
somx2 = Math.sqrt ((1.0 - x) * (1.0 + x));
fact = 1.0;
for (i = 1; i <= m; i++) {
pmm *= -fact * somx2;
fact += 2.0;
}
}if (l == m) return pmm;
 else {
pmmp1 = x * (2 * m + 1) * pmm;
if (l == (m + 1)) return pmmp1;
 else {
for (ll = (m + 2); ll <= l; ll++) {
pll = (x * (2 * ll - 1) * pmmp1 - (ll + m - 1) * pmm) / (ll - m);
pmm = pmmp1;
pmmp1 = pll;
}
return pll;
}}}, "~N,~N,~N");
Clazz.defineMethod (c$, "hypser", 
function (a, c, z) {
var n;
var fac = 1;
var result = 1;
for (n = 1; n <= 1000; n++) {
fac *= a * z / (n * c);
if (fac == 0) return result;
result += fac;
a++;
c++;
}
System.out.print ("convergence failure in hypser\n");
return 0;
}, "~N,~N,~N");
Clazz.defineMethod (c$, "setViewMatrix", 
function (a, b) {
var i;
for (i = 0; i != 9; i++) this.rotmatrix[i] = 0;

this.rotmatrix[0] = this.rotmatrix[4] = this.rotmatrix[8] = 1;
this.rotate (a, b);
}, "~N,~N");
Clazz.defineMethod (c$, "setXYViewExact", 
function () {
this.setViewMatrix (0, 0);
});
Clazz.defineMethod (c$, "setXZView", 
function () {
this.setViewMatrix (0, -1.2851969946503699);
});
Clazz.defineMethod (c$, "setXZViewExact", 
function () {
this.setViewMatrix (0, -1.5707963267948966);
});
Clazz.defineMethod (c$, "doSetup", 
function () {
var s = this.setupChooser.getSelectedIndex ();
var si = s * 7;
this.doClear ();
switch (this.setups[si]) {
case 0:
this.getState (1, 0, 0).setRe (1);
break;
case 1:
this.getState (2, 0, 0).setRe (1);
break;
case 2:
this.getState (2, 1, 1).setRe (1);
break;
case 3:
this.getState (2, 1, 1).setRe (0.7071067811865476);
this.getState (2, 1, -1).setRe (-0.7071067811865476);
break;
case 4:
this.getState (2, 1, 0).setRe (1);
break;
case 5:
this.getState (3, 0, 0).setRe (1);
break;
case 6:
this.getState (2, 1, -1).setRe (1);
break;
}
this.speedBar.setValue (this.setups[si + 1]);
this.strengthBar.setValue (this.setups[si + 2]);
this.brightnessBar.setValue (this.setups[si + 3]);
this.dirChooser.select (this.setups[si + 4]);
this.freqChooser.select (this.setups[si + 6]);
switch (this.setups[si + 5]) {
case 1:
this.setXZViewExact ();
break;
case 0:
this.setXYViewExact ();
break;
case 2:
this.setXZView ();
break;
}
});
c$.$AtomTransFrame$Orbital$ = function () {
Clazz.pu$h(c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.state = null;
this.n = 0;
this.l = 0;
this.m = 0;
this.reMult = 0;
this.imMult = 0;
this.dataR = null;
this.dataTh = null;
this.dataPhiR = null;
this.dataPhiI = null;
this.dshalf = 0;
this.brightnessCache = 0;
this.distmult = 4;
Clazz.instantialize (this, arguments);
}, com.falstad.AtomTransFrame, "Orbital");
Clazz.makeConstructor (c$, 
function (bs) {
this.n = bs.n;
this.l = bs.l;
this.m = bs.m;
this.state = bs;
}, "com.falstad.AtomTransFrame.BasisState");
Clazz.defineMethod (c$, "setupFrame", 
function (mult) {
this.reMult = (this.state.re * mult);
this.imMult = (this.state.im * mult);
}, "~N");
Clazz.defineMethod (c$, "getBoundRadius", 
function (bright) {
var i;
var outer = 1;
var mpos = (this.m < 0) ? -this.m : this.m;
var norm1 = 1 / this.sphericalNorm (this.l, mpos);
norm1 *= norm1;
norm1 *= bright;
for (i = 0; i != this.b$["com.falstad.AtomTransFrame"].dataSize; i++) {
var v = this.dataR[i] * this.dataR[i] * norm1;
if (v > 32) outer = i;
}
return outer / (this.b$["com.falstad.AtomTransFrame"].dataSize / 2.);
}, "~N");
Clazz.defineMethod (c$, "precompute", 
function () {
var x;
var y;
var z;
this.dshalf = Clazz.doubleToInt (this.b$["com.falstad.AtomTransFrame"].dataSize / 2);
var mult = this.b$["com.falstad.AtomTransFrame"].scaleBar.getValue () / 50.;
var mpos = (this.m < 0) ? -this.m : this.m;
var lgcorrect = Math.pow (-1, this.m);
var norm = this.radialNorm (this.n, this.l) * this.sphericalNorm (this.l, mpos);
this.dataR =  Clazz.newFloatArray (this.b$["com.falstad.AtomTransFrame"].dataSize, 0);
for (x = 0; x != this.b$["com.falstad.AtomTransFrame"].dataSize; x++) {
var r = x * this.b$["com.falstad.AtomTransFrame"].resadj + .00000001;
var rho = 2 * r * mult / this.n;
var rhol = Math.pow (rho, this.l) * norm;
this.dataR[x] = (this.b$["com.falstad.AtomTransFrame"].hypser (this.l + 1 - this.n, 2 * this.l + 2, rho) * rhol * Math.exp (-rho / 2));
}
if (this.l > 0) {
this.dataTh =  Clazz.newFloatArray (this.b$["com.falstad.AtomTransFrame"].dataSize + 1, 0);
for (x = 0; x != this.b$["com.falstad.AtomTransFrame"].dataSize + 1; x++) {
var th = (x - this.dshalf) / this.dshalf;
this.dataTh[x] = (lgcorrect * this.b$["com.falstad.AtomTransFrame"].plgndr (this.l, mpos, th));
}
}if (this.m != 0) {
this.dataPhiR =  Clazz.newFloatArray (8 * (this.b$["com.falstad.AtomTransFrame"].dataSize + 1), 0);
this.dataPhiI =  Clazz.newFloatArray (8 * (this.b$["com.falstad.AtomTransFrame"].dataSize + 1), 0);
var ix = 0;
for (x = 0; x != 8; x++) for (y = 0; y <= this.b$["com.falstad.AtomTransFrame"].dataSize; y++, ix++) {
var phi = x * 3.141592653589793 / 4 + y * (0.7853981633974483) / this.b$["com.falstad.AtomTransFrame"].dataSize;
this.dataPhiR[ix] = Math.cos (phi * mpos);
this.dataPhiI[ix] = Math.sin (phi * mpos);
}

}this.brightnessCache = 0;
});
Clazz.defineMethod (c$, "getBrightness", 
function () {
if (this.brightnessCache != 0) return this.brightnessCache;
var x;
var avgsq = 0;
var vol = 0;
var mpos = (this.m < 0) ? -this.m : this.m;
var norm1 = 1 / this.sphericalNorm (this.l, mpos);
for (x = 0; x != this.b$["com.falstad.AtomTransFrame"].dataSize; x++) {
var val = this.dataR[x] * norm1;
val *= val;
avgsq += val * val * x * x;
vol += x * x;
}
this.brightnessCache = avgsq / vol;
return this.brightnessCache;
});
Clazz.defineMethod (c$, "radialNorm", 
function (n, l) {
var a0 = this.factorial (n + l);
return Math.sqrt (4. * this.factorial (n + l) / (n * n * n * n * this.factorial (n - l - 1))) / this.factorial (2 * l + 1);
}, "~N,~N");
Clazz.defineMethod (c$, "sphericalNorm", 
function (l, m) {
return Math.sqrt ((2 * l + 1) * this.factorial (l - m) / (4 * 3.141592653589793 * this.factorial (l + m)));
}, "~N,~N");
Clazz.defineMethod (c$, "factorial", 
function (f) {
var res = 1;
while (f > 1) res *= f--;

return res;
}, "~N");
c$ = Clazz.p0p ();
};
c$.$AtomTransFrame$SOrbital$ = function () {
Clazz.pu$h(c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, com.falstad.AtomTransFrame, "SOrbital", com.falstad.AtomTransFrame.Orbital, null, Clazz.innerTypeInstance (com.falstad.AtomTransFrame.Orbital, this, null, Clazz.inheritArgs));
Clazz.overrideMethod (c$, "computePoint", 
function (r, costh) {
try {
var v = this.dataR[r];
this.b$["com.falstad.AtomTransFrame"].funcr = this.reMult * v;
this.b$["com.falstad.AtomTransFrame"].funci = this.imMult * v;
} catch (e) {
if (Clazz.exceptionOf (e, Exception)) {
this.b$["com.falstad.AtomTransFrame"].funcr = this.b$["com.falstad.AtomTransFrame"].funci = 0;
System.out.println ("bad " + r + " " + costh);
} else {
throw e;
}
}
}, "~N,~N");
c$ = Clazz.p0p ();
};
c$.$AtomTransFrame$MZeroOrbital$ = function () {
Clazz.pu$h(c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, com.falstad.AtomTransFrame, "MZeroOrbital", com.falstad.AtomTransFrame.Orbital, null, Clazz.innerTypeInstance (com.falstad.AtomTransFrame.Orbital, this, null, Clazz.inheritArgs));
Clazz.overrideMethod (c$, "computePoint", 
function (r, costh) {
try {
var v = this.dataR[r] * this.dataTh[costh];
this.b$["com.falstad.AtomTransFrame"].funcr = v * this.reMult;
this.b$["com.falstad.AtomTransFrame"].funci = v * this.imMult;
} catch (e) {
if (Clazz.exceptionOf (e, Exception)) {
this.b$["com.falstad.AtomTransFrame"].funcr = this.b$["com.falstad.AtomTransFrame"].funci = 0;
System.out.println ("bad " + r + " " + costh);
} else {
throw e;
}
}
}, "~N,~N");
c$ = Clazz.p0p ();
};
c$.$AtomTransFrame$PairedOrbital$ = function () {
Clazz.pu$h(c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.negstate = null;
this.f1 = 0;
this.f2 = 0;
this.f3 = 0;
this.f4 = 0;
Clazz.instantialize (this, arguments);
}, com.falstad.AtomTransFrame, "PairedOrbital", com.falstad.AtomTransFrame.Orbital, null, Clazz.innerTypeInstance (com.falstad.AtomTransFrame.Orbital, this, null, Clazz.inheritArgs));
Clazz.makeConstructor (c$, 
function (bs) {
Clazz.superConstructor (this, com.falstad.AtomTransFrame.PairedOrbital, [bs]);
this.negstate = this.b$["com.falstad.AtomTransFrame"].getState (bs.n, bs.l, -bs.m);
}, "com.falstad.AtomTransFrame.BasisState");
Clazz.overrideMethod (c$, "setupFrame", 
function (mult) {
var a = this.state.re * mult;
var b = this.state.im * mult;
var c = this.negstate.re * mult;
var d = this.negstate.im * mult;
var mphase = Math.pow (-1, this.m);
a *= mphase;
b *= mphase;
this.f1 = (a + c);
this.f2 = (d - b);
this.f3 = (b + d);
this.f4 = (a - c);
}, "~N");
Clazz.overrideMethod (c$, "computePoint", 
function (r, costh) {
try {
var q = this.dataR[r] * this.dataTh[costh];
var phiValR = this.dataPhiR[this.b$["com.falstad.AtomTransFrame"].phiIndex];
var phiValI = this.dataPhiI[this.b$["com.falstad.AtomTransFrame"].phiIndex];
this.b$["com.falstad.AtomTransFrame"].funcr = q * (this.f1 * phiValR + this.f2 * phiValI);
this.b$["com.falstad.AtomTransFrame"].funci = q * (this.f3 * phiValR + this.f4 * phiValI);
} catch (e) {
if (Clazz.exceptionOf (e, Exception)) {
this.b$["com.falstad.AtomTransFrame"].funcr = this.b$["com.falstad.AtomTransFrame"].funci = 0;
System.out.println ("bad " + r + " " + costh);
} else {
throw e;
}
}
}, "~N,~N");
c$ = Clazz.p0p ();
};
c$.$AtomTransFrame$Phasor$ = function () {
Clazz.pu$h(c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.state = null;
Clazz.instantialize (this, arguments);
}, com.falstad.AtomTransFrame, "Phasor", java.awt.Rectangle);
c$ = Clazz.p0p ();
};
c$.$AtomTransFrame$State$ = function () {
Clazz.pu$h(c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.elevel = 0;
this.index = 0;
Clazz.instantialize (this, arguments);
}, com.falstad.AtomTransFrame, "State", com.falstad.Complex);
Clazz.defineMethod (c$, "convertDerivedToBasis", 
function () {
});
Clazz.defineMethod (c$, "convertBasisToDerived", 
function () {
});
Clazz.defineMethod (c$, "setBasisActive", 
function () {
});
c$ = Clazz.p0p ();
};
c$.$AtomTransFrame$BasisState$ = function () {
Clazz.pu$h(c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.n = 0;
this.l = 0;
this.m = 0;
this.orb = null;
Clazz.instantialize (this, arguments);
}, com.falstad.AtomTransFrame, "BasisState", com.falstad.AtomTransFrame.State, null, Clazz.innerTypeInstance (com.falstad.AtomTransFrame.State, this, null, Clazz.inheritArgs));
Clazz.overrideMethod (c$, "getText", 
function () {
return "n = " + this.n + ", l = " + this.l + ", m = " + this.m;
});
c$ = Clazz.p0p ();
};
c$.$AtomTransFrame$PhaseColor$ = function () {
Clazz.pu$h(c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.r = 0;
this.g = 0;
this.b = 0;
Clazz.instantialize (this, arguments);
}, com.falstad.AtomTransFrame, "PhaseColor");
Clazz.makeConstructor (c$, 
function (rr, gg, bb) {
this.r = rr;
this.g = gg;
this.b = bb;
}, "~N,~N,~N");
c$ = Clazz.p0p ();
};
c$.$AtomTransFrame$View$ = function () {
Clazz.pu$h(c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.scale = 0;
this.paneY = 0;
this.pixels = null;
Clazz.instantialize (this, arguments);
}, com.falstad.AtomTransFrame, "View", java.awt.Rectangle);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, com.falstad.AtomTransFrame.View, []);
});
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"SLICE_NONE", 0,
"SLICE_X", 1,
"SLICE_Y", 2,
"SLICE_Z", 3,
"STATE_1S", 0,
"STATE_2S", 1,
"STATE_2P1", 2,
"STATE_2PX", 3,
"STATE_2PZ", 4,
"STATE_3S", 5,
"STATE_2PM1", 6,
"VIEW_XY", 0,
"VIEW_XZ", 1,
"VIEW_XZ12", 2,
"FREQ_12", 0,
"FREQ_13", 1,
"FREQ_14", 2,
"FREQ_23", 3,
"FREQ_24", 4,
"FREQ_34", 5,
"pi", 3.14159265358979323846,
"pi2", 6.283185307179586,
"root2", 1.41421356237309504880,
"root2inv", .70710678118654752440,
"maxModes", 10,
"maxDispCoefs", 8,
"viewDistance", 12,
"SEL_NONE", 0,
"SEL_POTENTIAL", 1,
"SEL_X", 2,
"SEL_STATES", 3,
"SEL_HANDLE", 4,
"MODE_ANGLE", 0,
"MODE_SLICE", 1,
"DIR_X", 0,
"DIR_Y", 1,
"DIR_Z", 2,
"DIR_CCW", 3,
"DIR_CW", 4,
"epsilon", .01,
"panePad", 4,
"phaseColorCount", 50);
});
