Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.ImportExportDialog", "java.awt.event.ActionListener", "swingjs.awt.Dialog"], "com.falstad.Circuit.ImportExportClipboardDialog", ["com.falstad.Circuit.ImportExportDialogLayout", "swingjs.awt.Button", "$.TextArea"], function () {
c$ = Clazz.decorateAsClass (function () {
this.cframe = null;
this.importButton = null;
this.closeButton = null;
this.text = null;
this.$type = null;
this.clipboard = null;
Clazz.instantialize (this, arguments);
}, com.falstad.Circuit, "ImportExportClipboardDialog", swingjs.awt.Dialog, [com.falstad.Circuit.ImportExportDialog, java.awt.event.ActionListener]);
Clazz.makeConstructor (c$, 
function (f, type) {
Clazz.superConstructor (this, com.falstad.Circuit.ImportExportClipboardDialog, [f, (type === com.falstad.Circuit.ImportExportDialog.Action.EXPORT) ? "Export" : "Import", false]);
this.cframe = f;
this.setLayout ( new com.falstad.Circuit.ImportExportDialogLayout ());
this.add (this.text =  new swingjs.awt.TextArea ("", 10, 60));
this.importButton =  new swingjs.awt.Button ("Import");
this.$type = type;
this.add (this.importButton);
this.importButton.addActionListener (this);
this.add (this.closeButton =  new swingjs.awt.Button ("Close"));
this.closeButton.addActionListener (this);
var x = this.cframe.main.getLocationOnScreen ();
this.resize (400, 300);
var d = this.getSize ();
this.setLocation (x.x + Clazz.doubleToInt ((this.cframe.winSize.width - d.width) / 2), x.y + Clazz.doubleToInt ((this.cframe.winSize.height - d.height) / 2));
}, "com.falstad.Circuit.CirSim,com.falstad.Circuit.ImportExportDialog.Action");
Clazz.overrideMethod (c$, "setDump", 
function (dump) {
this.text.setText (dump);
}, "~S");
Clazz.overrideMethod (c$, "execute", 
function () {
if (this.$type === com.falstad.Circuit.ImportExportDialog.Action.EXPORT) this.text.selectAll ();
this.setVisible (true);
});
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
var i;
var src = e.getSource ();
if (src === this.importButton) {
{
this.cframe.readSetup (this.text.getText ());
}}if (src === this.closeButton) this.setVisible (false);
}, "java.awt.event.ActionEvent");
Clazz.defineMethod (c$, "handleEvent", 
function (ev) {
if (ev.id == 201) {
this.cframe.main.requestFocus ();
this.setVisible (false);
this.cframe.impDialog = null;
return true;
}return Clazz.superCall (this, com.falstad.Circuit.ImportExportClipboardDialog, "handleEvent", [ev]);
}, "java.awt.Event");
});
