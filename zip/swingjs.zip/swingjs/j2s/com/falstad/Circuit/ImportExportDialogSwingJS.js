Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["a2s.Dialog", "com.falstad.Circuit.ImportExportDialog"], "com.falstad.Circuit.ImportExportDialogSwingJS", ["a2s.TextArea"], function () {
c$ = Clazz.decorateAsClass (function () {
this.cframe = null;
this.text = null;
this.$type = null;
Clazz.instantialize (this, arguments);
}, com.falstad.Circuit, "ImportExportDialogSwingJS", a2s.Dialog, com.falstad.Circuit.ImportExportDialog);
Clazz.makeConstructor (c$, 
function (f, type) {
Clazz.superConstructor (this, com.falstad.Circuit.ImportExportDialogSwingJS, [f, (type === com.falstad.Circuit.ImportExportDialog.Action.EXPORT) ? "Export" : "Import", false]);
this.cframe = f;
this.$type = type;
this.text =  new a2s.TextArea ("", 10, 60);
}, "com.falstad.Circuit.CirSim,com.falstad.Circuit.ImportExportDialog.Action");
Clazz.overrideMethod (c$, "setDump", 
function (dump) {
this.text.setText (dump);
}, "~S");
Clazz.overrideMethod (c$, "execute", 
function () {
if (this.$type === com.falstad.Circuit.ImportExportDialog.Action.IMPORT) {
{
swingjs.JSToolkit.getFileFromDialog(this, "string");
}} else {
var data = this.text.getText ();
var mimeType = "text/plain";
var encoding = null;
var fileName = null;
var name = com.falstad.Circuit.ImportExportDialogSwingJS.lastName;
{
fileName = prompt("Enter a file name", name); fileName &&
swingjs.JSToolkit.saveFile(fileName, data, mimeType,
encoding);
}}this.dispose ();
return;
});
Clazz.defineMethod (c$, "handleFileLoaded", 
function (data, fileName) {
if (fileName == null) return;
com.falstad.Circuit.ImportExportDialogSwingJS.lastName = fileName;
try {
this.cframe.readSetup (data);
} finally {
this.dispose ();
}
}, "~O,~S");
Clazz.defineMethod (c$, "handleEvent", 
function (ev) {
if (ev.id == 201) {
this.cframe.main.requestFocus ();
this.setVisible (false);
this.cframe.impDialog = null;
return true;
}return Clazz.superCall (this, com.falstad.Circuit.ImportExportDialogSwingJS, "handleEvent", [ev]);
}, "java.awt.Event");
Clazz.defineStatics (c$,
"lastName", "circuit.txt");
});
