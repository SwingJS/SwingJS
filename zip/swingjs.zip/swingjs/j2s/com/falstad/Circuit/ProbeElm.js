Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.CircuitElm"], "com.falstad.Circuit.ProbeElm", ["a2s.Checkbox", "com.falstad.Circuit.EditInfo", "java.awt.Font"], function () {
c$ = Clazz.decorateAsClass (function () {
this.center = null;
Clazz.instantialize (this, arguments);
}, com.falstad.Circuit, "ProbeElm", com.falstad.Circuit.CircuitElm);
Clazz.makeConstructor (c$, 
function (xa, ya, xb, yb, f, st) {
Clazz.superConstructor (this, com.falstad.Circuit.ProbeElm, [xa, ya, xb, yb, f]);
}, "~N,~N,~N,~N,~N,java.util.StringTokenizer");
Clazz.overrideMethod (c$, "getDumpType", 
function () {
return 'p';
});
Clazz.defineMethod (c$, "setPoints", 
function () {
Clazz.superCall (this, com.falstad.Circuit.ProbeElm, "setPoints", []);
if (this.point2.y < this.point1.y) {
var x = this.point1;
this.point1 = this.point2;
this.point2 = x;
}this.center = this.interpPoint (this.point1, this.point2, .5);
});
Clazz.overrideMethod (c$, "draw", 
function (g) {
var hs = 8;
this.setBbox (this.point1, this.point2, hs);
var selected = (this.needsHighlight () || com.falstad.Circuit.CircuitElm.sim.plotYElm === this);
var len = (selected || com.falstad.Circuit.CircuitElm.sim.dragElm === this) ? 16 : this.dn - 32;
this.calcLeads (Clazz.doubleToInt (len));
this.setVoltageColor (g, this.volts[0]);
if (selected) g.setColor (com.falstad.Circuit.CircuitElm.selectColor);
com.falstad.Circuit.CircuitElm.drawThickLine (g, this.point1, this.lead1);
this.setVoltageColor (g, this.volts[1]);
if (selected) g.setColor (com.falstad.Circuit.CircuitElm.selectColor);
com.falstad.Circuit.CircuitElm.drawThickLine (g, this.lead2, this.point2);
var f =  new java.awt.Font ("SansSerif", 1, 14);
g.setFont (f);
if (this === com.falstad.Circuit.CircuitElm.sim.plotXElm) this.drawCenteredText (g, "X", this.center.x, this.center.y, true);
if (this === com.falstad.Circuit.CircuitElm.sim.plotYElm) this.drawCenteredText (g, "Y", this.center.x, this.center.y, true);
if (this.mustShowVoltage ()) {
var s = com.falstad.Circuit.CircuitElm.getShortUnitText (this.volts[0], "V");
this.drawValues (g, s, 4);
}this.drawPosts (g);
}, "java.awt.Graphics");
Clazz.defineMethod (c$, "mustShowVoltage", 
function () {
return (this.flags & 1) != 0;
});
Clazz.overrideMethod (c$, "getInfo", 
function (arr) {
arr[0] = "scope probe";
arr[1] = "Vd = " + com.falstad.Circuit.CircuitElm.getVoltageText (this.getVoltageDiff ());
}, "~A");
Clazz.overrideMethod (c$, "getConnection", 
function (n1, n2) {
return false;
}, "~N,~N");
Clazz.overrideMethod (c$, "getEditInfo", 
function (n) {
if (n == 0) {
var ei =  new com.falstad.Circuit.EditInfo ("", 0, -1, -1);
ei.checkbox =  new a2s.Checkbox ("Show Voltage", this.mustShowVoltage ());
return ei;
}return null;
}, "~N");
Clazz.overrideMethod (c$, "setEditValue", 
function (n, ei) {
if (n == 0) {
if (ei.checkbox.getState ()) this.flags = 1;
 else this.flags &= -2;
}}, "~N,com.falstad.Circuit.EditInfo");
Clazz.defineStatics (c$,
"FLAG_SHOWVOLTAGE", 1);
});
