Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.VoltageElm"], "com.falstad.Circuit.DCVoltageElm", null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "DCVoltageElm", com.falstad.Circuit.VoltageElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.DCVoltageElm, [xx, yy, 0]);
}, "~N,~N");
Clazz.overrideMethod (c$, "getDumpClass", 
function () {
return com.falstad.Circuit.VoltageElm;
});
Clazz.overrideMethod (c$, "getShortcut", 
function () {
return 'v';
});
});
