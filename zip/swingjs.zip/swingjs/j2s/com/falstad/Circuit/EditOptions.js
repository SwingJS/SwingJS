Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.Editable"], "com.falstad.Circuit.EditOptions", ["com.falstad.Circuit.CircuitElm", "$.EditInfo"], function () {
c$ = Clazz.decorateAsClass (function () {
this.sim = null;
Clazz.instantialize (this, arguments);
}, com.falstad.Circuit, "EditOptions", null, com.falstad.Circuit.Editable);
Clazz.makeConstructor (c$, 
function (s) {
this.sim = s;
}, "com.falstad.Circuit.CirSim");
Clazz.overrideMethod (c$, "getEditInfo", 
function (n) {
if (n == 0) return  new com.falstad.Circuit.EditInfo ("Time step size (s)", this.sim.timeStep, 0, 0);
if (n == 1) return  new com.falstad.Circuit.EditInfo ("Range for voltage color (V)", com.falstad.Circuit.CircuitElm.voltageRange, 0, 0);
return null;
}, "~N");
Clazz.overrideMethod (c$, "setEditValue", 
function (n, ei) {
if (n == 0 && ei.value > 0) this.sim.timeStep = ei.value;
if (n == 1 && ei.value > 0) com.falstad.Circuit.CircuitElm.voltageRange = ei.value;
}, "~N,com.falstad.Circuit.EditInfo");
});
