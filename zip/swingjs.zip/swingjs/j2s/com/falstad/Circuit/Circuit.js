Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["java.awt.event.ComponentListener", "swingjs.awt.Applet"], "com.falstad.Circuit.Circuit", ["com.falstad.Circuit.CirSim"], function () {
c$ = Clazz.decorateAsClass (function () {
this.finished = false;
this.started = false;
Clazz.instantialize (this, arguments);
}, com.falstad.Circuit, "Circuit", swingjs.awt.Applet, java.awt.event.ComponentListener);
Clazz.defineMethod (c$, "destroyFrame", 
function () {
if (com.falstad.Circuit.Circuit.ogf != null) com.falstad.Circuit.Circuit.ogf.dispose ();
com.falstad.Circuit.Circuit.ogf = null;
this.repaint ();
this.finished = true;
});
Clazz.overrideMethod (c$, "init", 
function () {
this.addComponentListener (this);
this.showFrame ();
});
c$.main = Clazz.defineMethod (c$, "main", 
function (args) {
com.falstad.Circuit.Circuit.ogf =  new com.falstad.Circuit.CirSim (null);
com.falstad.Circuit.Circuit.ogf.init ();
}, "~A");
Clazz.defineMethod (c$, "showFrame", 
function () {
if (this.finished) {
this.repaint ();
return;
}if (com.falstad.Circuit.Circuit.ogf == null) {
this.started = true;
com.falstad.Circuit.Circuit.ogf =  new com.falstad.Circuit.CirSim (this);
com.falstad.Circuit.Circuit.ogf.init ();
}com.falstad.Circuit.Circuit.ogf.setVisible (true);
this.repaint ();
});
Clazz.defineMethod (c$, "hideFrame", 
function () {
if (this.finished) return;
com.falstad.Circuit.Circuit.ogf.setVisible (false);
this.repaint ();
});
Clazz.defineMethod (c$, "toggleSwitch", 
function (x) {
com.falstad.Circuit.Circuit.ogf.toggleSwitch (x);
}, "~N");
Clazz.defineMethod (c$, "paint", 
function (g) {
Clazz.superCall (this, com.falstad.Circuit.Circuit, "paint", [g]);
var s = "Applet is open in a separate window.";
if (com.falstad.Circuit.Circuit.ogf != null && !com.falstad.Circuit.Circuit.ogf.isVisible ()) s = "Applet window is hidden.";
if (!this.started) s = "Applet is starting.";
 else if (com.falstad.Circuit.Circuit.ogf == null || this.finished) s = "Applet is finished.";
 else if (com.falstad.Circuit.Circuit.ogf != null && com.falstad.Circuit.Circuit.ogf.useFrame) com.falstad.Circuit.Circuit.ogf.triggerShow ();
g.drawString (s, 10, 30);
}, "java.awt.Graphics");
Clazz.overrideMethod (c$, "componentHidden", 
function (e) {
}, "java.awt.event.ComponentEvent");
Clazz.overrideMethod (c$, "componentMoved", 
function (e) {
}, "java.awt.event.ComponentEvent");
Clazz.overrideMethod (c$, "componentShown", 
function (e) {
this.showFrame ();
}, "java.awt.event.ComponentEvent");
Clazz.overrideMethod (c$, "componentResized", 
function (e) {
if (com.falstad.Circuit.Circuit.ogf != null) com.falstad.Circuit.Circuit.ogf.componentResized (e);
}, "java.awt.event.ComponentEvent");
Clazz.overrideMethod (c$, "destroy", 
function () {
if (com.falstad.Circuit.Circuit.ogf != null) com.falstad.Circuit.Circuit.ogf.dispose ();
com.falstad.Circuit.Circuit.ogf = null;
this.repaint ();
});
Clazz.defineStatics (c$,
"ogf", null);
});
