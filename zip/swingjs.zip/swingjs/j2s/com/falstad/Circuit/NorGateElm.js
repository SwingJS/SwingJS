Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.OrGateElm"], "com.falstad.Circuit.NorGateElm", null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "NorGateElm", com.falstad.Circuit.OrGateElm);
Clazz.overrideMethod (c$, "getGateName", 
function () {
return "NOR gate";
});
Clazz.overrideMethod (c$, "isInverting", 
function () {
return true;
});
Clazz.overrideMethod (c$, "getDumpType", 
function () {
return 153;
});
Clazz.overrideMethod (c$, "getShortcut", 
function () {
return '#';
});
});
