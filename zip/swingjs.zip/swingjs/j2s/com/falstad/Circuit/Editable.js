Clazz.declarePackage ("com.falstad.Circuit");
Clazz.declareInterface (com.falstad.Circuit, "Editable");
