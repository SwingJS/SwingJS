Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.CircuitElm"], "com.falstad.Circuit.OutputElm", ["com.falstad.Circuit.EditInfo", "java.awt.Font", "$.Point", "swingjs.awt.Checkbox"], function () {
c$ = Clazz.decorateAsClass (function () {
this.FLAG_VALUE = 1;
Clazz.instantialize (this, arguments);
}, com.falstad.Circuit, "OutputElm", com.falstad.Circuit.CircuitElm);
Clazz.makeConstructor (c$, 
function (xa, ya, xb, yb, f, st) {
Clazz.superConstructor (this, com.falstad.Circuit.OutputElm, [xa, ya, xb, yb, f]);
}, "~N,~N,~N,~N,~N,java.util.StringTokenizer");
Clazz.overrideMethod (c$, "getDumpType", 
function () {
return 'O';
});
Clazz.overrideMethod (c$, "getPostCount", 
function () {
return 1;
});
Clazz.defineMethod (c$, "setPoints", 
function () {
Clazz.superCall (this, com.falstad.Circuit.OutputElm, "setPoints", []);
this.lead1 =  new java.awt.Point ();
});
Clazz.overrideMethod (c$, "draw", 
function (g) {
var selected = (this.needsHighlight () || com.falstad.Circuit.CircuitElm.sim.plotYElm === this);
var f =  new java.awt.Font ("SansSerif", selected ? 1 : 0, 14);
g.setFont (f);
g.setColor (selected ? com.falstad.Circuit.CircuitElm.selectColor : com.falstad.Circuit.CircuitElm.whiteColor);
var s = (this.flags & 1) != 0 ? com.falstad.Circuit.CircuitElm.getVoltageText (this.volts[0]) : "out";
var fm = g.getFontMetrics ();
if (this === com.falstad.Circuit.CircuitElm.sim.plotXElm) s = "X";
if (this === com.falstad.Circuit.CircuitElm.sim.plotYElm) s = "Y";
this.interpPoint (this.point1, this.point2, this.lead1, 1 - (Clazz.doubleToInt (fm.stringWidth (s) / 2) + 8) / this.dn);
this.setBbox (this.point1, this.lead1, 0);
this.drawCenteredText (g, s, this.x2, this.y2, true);
this.setVoltageColor (g, this.volts[0]);
if (selected) g.setColor (com.falstad.Circuit.CircuitElm.selectColor);
com.falstad.Circuit.CircuitElm.drawThickLine (g, this.point1, this.lead1);
this.drawPosts (g);
}, "java.awt.Graphics");
Clazz.overrideMethod (c$, "getVoltageDiff", 
function () {
return this.volts[0];
});
Clazz.overrideMethod (c$, "getInfo", 
function (arr) {
arr[0] = "output";
arr[1] = "V = " + com.falstad.Circuit.CircuitElm.getVoltageText (this.volts[0]);
}, "~A");
Clazz.overrideMethod (c$, "getEditInfo", 
function (n) {
if (n == 0) {
var ei =  new com.falstad.Circuit.EditInfo ("", 0, -1, -1);
ei.checkbox =  new swingjs.awt.Checkbox ("Show Voltage", (this.flags & 1) != 0);
return ei;
}return null;
}, "~N");
Clazz.overrideMethod (c$, "setEditValue", 
function (n, ei) {
if (n == 0) this.flags = (ei.checkbox.getState ()) ? (this.flags | 1) : (this.flags & -2);
}, "~N,com.falstad.Circuit.EditInfo");
});
