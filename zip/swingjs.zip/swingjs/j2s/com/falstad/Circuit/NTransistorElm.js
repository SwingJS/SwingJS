Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.TransistorElm"], "com.falstad.Circuit.NTransistorElm", null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "NTransistorElm", com.falstad.Circuit.TransistorElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.NTransistorElm, [xx, yy, false]);
}, "~N,~N");
Clazz.overrideMethod (c$, "getDumpClass", 
function () {
return com.falstad.Circuit.TransistorElm;
});
});
