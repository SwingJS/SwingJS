Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.CircuitElm"], "com.falstad.Circuit.GraphicElm", null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "GraphicElm", com.falstad.Circuit.CircuitElm);
Clazz.overrideMethod (c$, "getPostCount", 
function () {
return 0;
});
});
