Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.OpAmpElm"], "com.falstad.Circuit.OpAmpSwapElm", null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "OpAmpSwapElm", com.falstad.Circuit.OpAmpElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.OpAmpSwapElm, [xx, yy]);
this.flags |= 1;
}, "~N,~N");
Clazz.overrideMethod (c$, "getDumpClass", 
function () {
return com.falstad.Circuit.OpAmpElm;
});
});
