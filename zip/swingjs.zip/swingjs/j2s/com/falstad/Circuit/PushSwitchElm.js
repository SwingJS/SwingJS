Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.SwitchElm"], "com.falstad.Circuit.PushSwitchElm", null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "PushSwitchElm", com.falstad.Circuit.SwitchElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.PushSwitchElm, [xx, yy, true]);
}, "~N,~N");
Clazz.overrideMethod (c$, "getDumpClass", 
function () {
return com.falstad.Circuit.SwitchElm;
});
Clazz.overrideMethod (c$, "getShortcut", 
function () {
return 0;
});
});
