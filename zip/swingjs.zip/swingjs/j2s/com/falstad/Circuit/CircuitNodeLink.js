Clazz.declarePackage ("com.falstad.Circuit");
c$ = Clazz.decorateAsClass (function () {
this.num = 0;
this.elm = null;
Clazz.instantialize (this, arguments);
}, com.falstad.Circuit, "CircuitNodeLink");
