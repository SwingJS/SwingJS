Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.AndGateElm"], "com.falstad.Circuit.NandGateElm", null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "NandGateElm", com.falstad.Circuit.AndGateElm);
Clazz.overrideMethod (c$, "isInverting", 
function () {
return true;
});
Clazz.overrideMethod (c$, "getGateName", 
function () {
return "NAND gate";
});
Clazz.overrideMethod (c$, "getDumpType", 
function () {
return 151;
});
Clazz.overrideMethod (c$, "getShortcut", 
function () {
return '@';
});
});
