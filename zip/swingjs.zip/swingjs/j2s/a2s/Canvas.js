Clazz.declarePackage ("a2s");
Clazz.load (["a2s.Panel"], "a2s.Canvas", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.notified = false;
Clazz.instantialize (this, arguments);
}, a2s, "Canvas", a2s.Panel);
Clazz.overrideMethod (c$, "paint", 
function (g) {
this.update (g);
}, "java.awt.Graphics");
Clazz.overrideMethod (c$, "update", 
function (g) {
if (!this.notified) System.out.println ("neither paint(g) nor update(g) is implemented for " + this);
this.notified = true;
}, "java.awt.Graphics");
});
