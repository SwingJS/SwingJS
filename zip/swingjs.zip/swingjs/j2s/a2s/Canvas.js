Clazz.declarePackage ("a2s");
Clazz.load (["a2s.Panel"], "a2s.Canvas", null, function () {
c$ = Clazz.declareType (a2s, "Canvas", a2s.Panel);
});
