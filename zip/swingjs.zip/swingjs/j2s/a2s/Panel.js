Clazz.declarePackage ("a2s");
Clazz.load (["java.awt.event.ActionListener", "javax.swing.JPanel"], "a2s.Panel", ["a2s.A2SEvent", "$.TextField", "javax.swing.AbstractButton", "$.JComboBox"], function () {
c$ = Clazz.declareType (a2s, "Panel", javax.swing.JPanel, java.awt.event.ActionListener);
Clazz.defineMethod (c$, "add", 
function (comp) {
Clazz.superCall (this, a2s.Panel, "add", [comp]);
if (Clazz.instanceOf (comp, javax.swing.AbstractButton)) {
(comp).addActionListener (this);
} else if (Clazz.instanceOf (comp, a2s.TextField)) {
(comp).addActionListener (this);
} else if (Clazz.instanceOf (comp, javax.swing.JComboBox)) {
(comp).addActionListener (this);
}return comp;
}, "java.awt.Component");
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
 new a2s.A2SEvent (this, e).run ();
}, "java.awt.event.ActionEvent");
});
