Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JPanel"], "a2s.Panel", null, function () {
c$ = Clazz.declareType (a2s, "Panel", javax.swing.JPanel);
});
