Clazz.declarePackage ("a2s");
Clazz.load (null, "a2s.A2SEvent", ["a2s.Choice", "$.Dialog", "$.Frame", "$.List", "$.MenuItem", "$.TextField", "java.awt.Event", "java.lang.Boolean", "javax.swing.AbstractButton", "$.JComboBox", "$.JScrollBar"], function () {
c$ = Clazz.decorateAsClass (function () {
this.e = null;
this.c = null;
Clazz.instantialize (this, arguments);
}, a2s, "A2SEvent", null, Runnable);
Clazz.makeConstructor (c$, 
function (c, e) {
this.c = c;
this.e = a2s.A2SEvent.convertToOld (e);
}, "java.awt.Component,java.awt.AWTEvent");
Clazz.overrideMethod (c$, "run", 
function () {
var c = this.c;
var e = this.e;
{
setTimeout(function() { c.handleEvent(e);});
}});
c$.getOldEventKey = Clazz.defineMethod (c$, "getOldEventKey", 
function (e) {
var keyCode = e.getKeyCode ();
for (var i = 0; i < a2s.A2SEvent.actionKeyCodes.length; i++) {
if (a2s.A2SEvent.actionKeyCodes[i][0] == keyCode) {
return a2s.A2SEvent.actionKeyCodes[i][1];
}}
return (e.getKeyChar ()).charCodeAt (0);
}, "java.awt.event.KeyEvent");
c$.convertToOld = Clazz.defineMethod (c$, "convertToOld", 
function (e) {
var src = e.getSource ();
var id = e.getID ();
var newid = id;
switch (id) {
case 401:
case 402:
var ke = e;
if (ke.isActionKey ()) {
newid = (id == 401 ? 403 : 404);
}var keyCode = ke.getKeyCode ();
if (keyCode == 16 || keyCode == 17 || keyCode == 18) {
return null;
}return  new java.awt.Event (src, ke.getWhen (), newid, 0, 0, a2s.A2SEvent.getOldEventKey (ke), (ke.getModifiers () & -17));
case 501:
case 502:
case 503:
case 506:
case 504:
case 505:
var me = e;
var olde =  new java.awt.Event (src, me.getWhen (), newid, me.getX (), me.getY (), 0, (me.getModifiers () & -17));
olde.clickCount = me.getClickCount ();
return olde;
case 1004:
return  new java.awt.Event (src, 1004, null);
case 1005:
return  new java.awt.Event (src, 1005, null);
case 201:
case 203:
case 204:
return  new java.awt.Event (src, newid, null);
case 100:
if (Clazz.instanceOf (src, a2s.Frame) || Clazz.instanceOf (src, a2s.Dialog)) {
var p = (src).getLocation ();
return  new java.awt.Event (src, 0, 205, p.x, p.y, 0, 0);
}break;
case 1001:
var ae = e;
var cmd;
if (Clazz.instanceOf (src, javax.swing.AbstractButton)) {
cmd = (src).getText ();
} else if (Clazz.instanceOf (src, a2s.MenuItem)) {
cmd = (src).getText ();
} else {
cmd = ae.getActionCommand ();
}return  new java.awt.Event (src, 0, newid, 0, 0, 0, ae.getModifiers (), cmd);
case 701:
var ie = e;
var arg;
if (Clazz.instanceOf (src, a2s.List)) {
newid = (ie.getStateChange () == 1 ? 701 : 702);
arg = ie.getItem ();
} else {
newid = 1001;
if (Clazz.instanceOf (src, a2s.Choice)) {
arg = ie.getItem ();
} else {
arg = Boolean.$valueOf (ie.getStateChange () == 1);
}}return  new java.awt.Event (src, newid, arg);
case 601:
var aje = e;
switch (aje.getAdjustmentType ()) {
case 1:
newid = 602;
break;
case 2:
newid = 601;
break;
case 4:
newid = 604;
break;
case 3:
newid = 603;
break;
case 5:
if (aje.getValueIsAdjusting ()) {
newid = 605;
} else {
newid = 607;
}break;
default:
return null;
}
return  new java.awt.Event (src, newid, Integer.$valueOf (aje.getValue ()));
default:
}
return null;
}, "java.awt.AWTEvent");
c$.addComponent = Clazz.defineMethod (c$, "addComponent", 
function (listener, comp) {
if (Clazz.instanceOf (comp, javax.swing.AbstractButton)) {
(comp).addActionListener (listener);
} else if (Clazz.instanceOf (comp, a2s.TextField)) {
(comp).addActionListener (listener);
} else if (Clazz.instanceOf (comp, javax.swing.JComboBox)) {
(comp).addActionListener (listener);
} else if (Clazz.instanceOf (comp, javax.swing.JScrollBar)) {
(comp).addAdjustmentListener (listener);
}return comp;
}, "java.util.EventListener,java.awt.Component");
Clazz.defineStatics (c$,
"actionKeyCodes",  Clazz.newArray (-1, [ Clazz.newIntArray (-1, [36, 1000]),  Clazz.newIntArray (-1, [35, 1001]),  Clazz.newIntArray (-1, [33, 1002]),  Clazz.newIntArray (-1, [34, 1003]),  Clazz.newIntArray (-1, [38, 1004]),  Clazz.newIntArray (-1, [40, 1005]),  Clazz.newIntArray (-1, [37, 1006]),  Clazz.newIntArray (-1, [39, 1007]),  Clazz.newIntArray (-1, [112, 1008]),  Clazz.newIntArray (-1, [113, 1009]),  Clazz.newIntArray (-1, [114, 1010]),  Clazz.newIntArray (-1, [115, 1011]),  Clazz.newIntArray (-1, [116, 1012]),  Clazz.newIntArray (-1, [117, 1013]),  Clazz.newIntArray (-1, [118, 1014]),  Clazz.newIntArray (-1, [119, 1015]),  Clazz.newIntArray (-1, [120, 1016]),  Clazz.newIntArray (-1, [121, 1017]),  Clazz.newIntArray (-1, [122, 1018]),  Clazz.newIntArray (-1, [123, 1019]),  Clazz.newIntArray (-1, [154, 1020]),  Clazz.newIntArray (-1, [145, 1021]),  Clazz.newIntArray (-1, [20, 1022]),  Clazz.newIntArray (-1, [144, 1023]),  Clazz.newIntArray (-1, [19, 1024]),  Clazz.newIntArray (-1, [155, 1025])]));
});
