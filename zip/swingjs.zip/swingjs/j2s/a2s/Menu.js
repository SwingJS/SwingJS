Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JMenu"], "a2s.Menu", null, function () {
c$ = Clazz.declareType (a2s, "Menu", javax.swing.JMenu);
Clazz.makeConstructor (c$, 
function (title) {
Clazz.superConstructor (this, a2s.Menu, [title]);
title = null;
}, "~S");
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, a2s.Menu);
var s = null;
});
Clazz.defineMethod (c$, "countItems", 
function () {
return Clazz.superCall (this, a2s.Menu, "getComponentCount", []);
});
});
