Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JTextArea"], "a2s.TextArea", null, function () {
c$ = Clazz.declareType (a2s, "TextArea", javax.swing.JTextArea);
Clazz.makeConstructor (c$, 
function (text) {
Clazz.superConstructor (this, a2s.TextArea, [text, 0, 9]);
}, "~S");
});
