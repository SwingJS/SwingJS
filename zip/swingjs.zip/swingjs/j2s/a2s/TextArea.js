Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JTextArea"], "a2s.TextArea", null, function () {
c$ = Clazz.declareType (a2s, "TextArea", javax.swing.JTextArea);
});
