Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JScrollPane"], "a2s.TextArea", ["javax.swing.JTextArea"], function () {
c$ = Clazz.decorateAsClass (function () {
this.ta = null;
Clazz.instantialize (this, arguments);
}, a2s, "TextArea", javax.swing.JScrollPane);
Clazz.makeConstructor (c$, 
function (rows, cols) {
Clazz.superConstructor (this, a2s.TextArea);
this.setViewportView (this.ta =  new javax.swing.JTextArea (rows, cols));
this.awtDefaults ();
}, "~N,~N");
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, a2s.TextArea);
this.setViewportView (this.ta =  new javax.swing.JTextArea ());
this.awtDefaults ();
});
Clazz.makeConstructor (c$, 
function (text) {
Clazz.superConstructor (this, a2s.TextArea);
this.setViewportView (this.ta =  new javax.swing.JTextArea (text, 0, 9));
this.awtDefaults ();
}, "~S");
Clazz.makeConstructor (c$, 
function (text, rows, cols) {
Clazz.superConstructor (this, a2s.TextArea);
this.setViewportView (this.ta =  new javax.swing.JTextArea (text, rows, cols));
this.awtDefaults ();
}, "~S,~N,~N");
Clazz.defineMethod (c$, "awtDefaults", 
function () {
});
Clazz.defineMethod (c$, "getText", 
function () {
return this.ta.getText ();
});
Clazz.defineMethod (c$, "setEditable", 
function (b) {
this.ta.setEditable (b);
}, "~B");
Clazz.defineMethod (c$, "selectAll", 
function () {
this.ta.selectAll ();
});
Clazz.defineMethod (c$, "setText", 
function (t) {
this.ta.setText (t);
}, "~S");
Clazz.defineMethod (c$, "insertText", 
function (str, pos) {
this.ta.insert (str, pos);
}, "~S,~N");
Clazz.defineMethod (c$, "insert", 
function (str, pos) {
this.ta.insert (str, pos);
}, "~S,~N");
Clazz.defineMethod (c$, "appendText", 
function (str) {
this.ta.append (str);
}, "~S");
Clazz.defineMethod (c$, "append", 
function (str) {
this.ta.append (str);
}, "~S");
Clazz.defineMethod (c$, "replaceRange", 
function (str, start, end) {
this.ta.replaceRange (str, start, end);
}, "~S,~N,~N");
Clazz.defineMethod (c$, "replaceText", 
function (str, start, end) {
this.ta.replaceRange (str, start, end);
}, "~S,~N,~N");
Clazz.defineMethod (c$, "setColumns", 
function (columns) {
this.ta.setColumns (columns);
}, "~N");
Clazz.defineMethod (c$, "setRows", 
function (rows) {
this.ta.setRows (rows);
}, "~N");
Clazz.defineMethod (c$, "getColumns", 
function () {
return this.ta.getColumns ();
});
Clazz.defineMethod (c$, "getRows", 
function () {
return this.ta.getRows ();
});
});
