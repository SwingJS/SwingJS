Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JApplet"], "a2s.Applet", null, function () {
c$ = Clazz.declareType (a2s, "Applet", javax.swing.JApplet);
});
