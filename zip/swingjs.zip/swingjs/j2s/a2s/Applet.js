Clazz.declarePackage ("a2s");
Clazz.load (["java.awt.event.ActionListener", "$.AdjustmentListener", "$.KeyListener", "$.MouseListener", "$.MouseMotionListener", "javax.swing.JApplet"], "a2s.Applet", ["a2s.A2SEvent", "javax.swing.JPanel"], function () {
c$ = Clazz.declareType (a2s, "Applet", javax.swing.JApplet, [java.awt.event.AdjustmentListener, java.awt.event.ActionListener, java.awt.event.KeyListener, java.awt.event.MouseListener, java.awt.event.MouseMotionListener]);
Clazz.overrideMethod (c$, "init", 
function () {
this.addMouseListener (this);
this.addMouseMotionListener (this);
this.setContentPane (((Clazz.isClassDefined ("a2s.Applet$1") ? 0 : a2s.Applet.$Applet$1$ ()), Clazz.innerTypeInstance (a2s.Applet$1, this, null)));
});
Clazz.defineMethod (c$, "paintMe", 
function (g) {
System.out.println ("paintMe has not been implemented!");
}, "java.awt.Graphics");
Clazz.defineMethod (c$, "add", 
function (comp) {
Clazz.superCall (this, a2s.Applet, "add", [comp]);
return a2s.A2SEvent.addComponent (this, comp);
}, "java.awt.Component");
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
 new a2s.A2SEvent (this, e).run ();
}, "java.awt.event.ActionEvent");
Clazz.overrideMethod (c$, "mouseDragged", 
function (e) {
 new a2s.A2SEvent (this, e).run ();
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mouseMoved", 
function (e) {
 new a2s.A2SEvent (this, e).run ();
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mouseClicked", 
function (e) {
 new a2s.A2SEvent (this, e).run ();
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mousePressed", 
function (e) {
 new a2s.A2SEvent (this, e).run ();
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mouseReleased", 
function (e) {
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mouseEntered", 
function (e) {
 new a2s.A2SEvent (this, e).run ();
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mouseExited", 
function (e) {
 new a2s.A2SEvent (this, e).run ();
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "keyTyped", 
function (e) {
 new a2s.A2SEvent (this, e).run ();
}, "java.awt.event.KeyEvent");
Clazz.overrideMethod (c$, "keyPressed", 
function (e) {
 new a2s.A2SEvent (this, e).run ();
}, "java.awt.event.KeyEvent");
Clazz.overrideMethod (c$, "keyReleased", 
function (e) {
 new a2s.A2SEvent (this, e).run ();
}, "java.awt.event.KeyEvent");
Clazz.overrideMethod (c$, "adjustmentValueChanged", 
function (e) {
 new a2s.A2SEvent (this, e).run ();
}, "java.awt.event.AdjustmentEvent");
c$.$Applet$1$ = function () {
Clazz.pu$h(c$);
c$ = Clazz.declareAnonymous (a2s, "Applet$1", javax.swing.JPanel);
Clazz.defineMethod (c$, "paintComponent", 
function (g) {
Clazz.superCall (this, a2s.Applet$1, "paintComponent", [g]);
try {
if (this.getWidth () > 0) this.b$["a2s.Applet"].paintMe (g);
} catch (e) {
System.out.println (e);
e.printStackTrace ();
{
debugger;
}}
}, "java.awt.Graphics");
c$ = Clazz.p0p ();
};
});
