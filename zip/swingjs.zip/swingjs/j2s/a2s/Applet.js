Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JApplet"], "a2s.Applet", ["a2s.A2SEvent", "$.A2SListener", "javax.swing.JPanel"], function () {
c$ = Clazz.decorateAsClass (function () {
this.listener = null;
Clazz.instantialize (this, arguments);
}, a2s, "Applet", javax.swing.JApplet);
Clazz.overrideMethod (c$, "init", 
function () {
this.listener =  new a2s.A2SListener (this);
this.addMouseListener (this.listener);
this.addMouseMotionListener (this.listener);
this.setContentPane (((Clazz.isClassDefined ("a2s.Applet$1") ? 0 : a2s.Applet.$Applet$1$ ()), Clazz.innerTypeInstance (a2s.Applet$1, this, null)));
});
Clazz.defineMethod (c$, "paintMe", 
function (g) {
System.out.println ("paintMe has not been implemented!");
}, "java.awt.Graphics");
Clazz.defineMethod (c$, "add", 
function (comp) {
Clazz.superCall (this, a2s.Applet, "add", [comp]);
return a2s.A2SEvent.addComponent (this.listener, comp);
}, "java.awt.Component");
c$.$Applet$1$ = function () {
Clazz.pu$h (c$);
c$ = Clazz.declareAnonymous (a2s, "Applet$1", javax.swing.JPanel);
Clazz.defineMethod (c$, "paintComponent", 
function (g) {
Clazz.superCall (this, a2s.Applet$1, "paintComponent", [g]);
try {
if (this.getWidth () > 0) this.b$["a2s.Applet"].paintMe (g);
} catch (e) {
System.out.println (e);
e.printStackTrace ();
{
debugger;
}}
}, "java.awt.Graphics");
var rc = c$;
c$ = Clazz.p0p ();
return rc;
};
});
