Clazz.declarePackage ("a2s");
c$ = Clazz.declareType (a2s, "Util");
c$.drawString = Clazz.defineMethod (c$, "drawString", 
function (g, text, x, y) {
{
g.drawStringUnique(text, x, y);
}}, "java.awt.Graphics,~S,~N,~N");
