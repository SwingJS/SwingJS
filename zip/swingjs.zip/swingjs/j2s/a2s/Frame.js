Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JFrame"], "a2s.Frame", null, function () {
c$ = Clazz.declareType (a2s, "Frame", javax.swing.JFrame);
Clazz.defineMethod (c$, "remove", 
function (i) {
{
this.removeInt(i);
}}, "~N");
Clazz.defineMethod (c$, "setMenuBar", 
function (m) {
this.setJMenuBar (m);
}, "a2s.MenuBar");
Clazz.defineMethod (c$, "unsetMenuBar", 
function () {
this.setJMenuBar (null);
});
Clazz.defineMethod (c$, "getMenubar", 
function () {
return this.getJMenuBar ();
});
});
