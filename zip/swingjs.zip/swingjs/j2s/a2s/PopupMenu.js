Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JPopupMenu"], "a2s.PopupMenu", null, function () {
c$ = Clazz.declareType (a2s, "PopupMenu", javax.swing.JPopupMenu);
});
