Clazz.declarePackage ("a2s");
Clazz.load (["java.awt.event.ActionListener", "$.AdjustmentListener", "$.KeyListener", "$.MouseListener", "$.MouseMotionListener"], "a2s.A2SListener", ["a2s.A2SEvent"], function () {
c$ = Clazz.decorateAsClass (function () {
this.applet = null;
Clazz.instantialize (this, arguments);
}, a2s, "A2SListener", null, [java.awt.event.AdjustmentListener, java.awt.event.ActionListener, java.awt.event.KeyListener, java.awt.event.MouseListener, java.awt.event.MouseMotionListener]);
Clazz.makeConstructor (c$, 
function (applet) {
this.applet = applet;
}, "a2s.Applet");
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
 new a2s.A2SEvent (this.applet, e).run ();
}, "java.awt.event.ActionEvent");
Clazz.overrideMethod (c$, "mouseDragged", 
function (e) {
 new a2s.A2SEvent (this.applet, e).run ();
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mouseMoved", 
function (e) {
 new a2s.A2SEvent (this.applet, e).run ();
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mouseClicked", 
function (e) {
 new a2s.A2SEvent (this.applet, e).run ();
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mousePressed", 
function (e) {
 new a2s.A2SEvent (this.applet, e).run ();
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mouseReleased", 
function (e) {
 new a2s.A2SEvent (this.applet, e).run ();
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mouseEntered", 
function (e) {
 new a2s.A2SEvent (this.applet, e).run ();
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "mouseExited", 
function (e) {
 new a2s.A2SEvent (this.applet, e).run ();
}, "java.awt.event.MouseEvent");
Clazz.overrideMethod (c$, "keyTyped", 
function (e) {
 new a2s.A2SEvent (this.applet, e).run ();
}, "java.awt.event.KeyEvent");
Clazz.overrideMethod (c$, "keyPressed", 
function (e) {
 new a2s.A2SEvent (this.applet, e).run ();
}, "java.awt.event.KeyEvent");
Clazz.overrideMethod (c$, "keyReleased", 
function (e) {
 new a2s.A2SEvent (this.applet, e).run ();
}, "java.awt.event.KeyEvent");
Clazz.overrideMethod (c$, "adjustmentValueChanged", 
function (e) {
 new a2s.A2SEvent (this.applet, e).run ();
}, "java.awt.event.AdjustmentEvent");
});
