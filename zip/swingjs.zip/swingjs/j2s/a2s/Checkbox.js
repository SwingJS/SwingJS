Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JCheckBox"], "a2s.Checkbox", ["javax.swing.JRadioButton"], function () {
c$ = Clazz.declareType (a2s, "Checkbox", javax.swing.JCheckBox);
c$.newRadioButton = Clazz.defineMethod (c$, "newRadioButton", 
function (string, bg, b) {
var rb =  new javax.swing.JRadioButton (string, b);
bg.add (rb);
return rb;
}, "~S,javax.swing.ButtonGroup,~B");
Clazz.makeConstructor (c$, 
function (string) {
Clazz.superConstructor (this, a2s.Checkbox, [string, false]);
}, "~S");
Clazz.defineMethod (c$, "getState", 
function () {
return this.isSelected ();
});
Clazz.defineMethod (c$, "setState", 
function (b) {
this.setSelected (b);
}, "~B");
});
