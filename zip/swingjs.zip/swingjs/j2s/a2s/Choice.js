Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JComboBox"], "a2s.Choice", null, function () {
c$ = Clazz.declareType (a2s, "Choice", javax.swing.JComboBox);
Clazz.defineMethod (c$, "select", 
function (index) {
this.setSelectedIndex (index);
}, "~N");
Clazz.defineMethod (c$, "select", 
function (key) {
this.setSelectedItem (key);
}, "~S");
Clazz.defineMethod (c$, "add", 
function (label) {
this.addItem (label);
}, "~S");
Clazz.defineMethod (c$, "getItem", 
function (n) {
return this.getItemAt (n);
}, "~N");
});
