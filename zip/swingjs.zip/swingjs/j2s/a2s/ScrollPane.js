Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JScrollPane"], "a2s.ScrollPane", null, function () {
c$ = Clazz.declareType (a2s, "ScrollPane", javax.swing.JScrollPane);
});
