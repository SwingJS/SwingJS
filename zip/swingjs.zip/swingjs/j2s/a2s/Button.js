Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JButton"], "a2s.Button", null, function () {
c$ = Clazz.declareType (a2s, "Button", javax.swing.JButton);
});
