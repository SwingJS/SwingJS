Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JDialog"], "a2s.Dialog", null, function () {
c$ = Clazz.declareType (a2s, "Dialog", javax.swing.JDialog);
});
