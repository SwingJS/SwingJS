The Jama directory is only used by the Falstad applets.

It is not part of SwingJS and can be ignored if com.falstad is not included.
