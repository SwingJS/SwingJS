Clazz.declarePackage ("Jama");
Clazz.load (null, "Jama.Matrix", ["Jama.EigenvalueDecomposition", "$.LUDecomposition", "$.QRDecomposition", "$.SingularValueDecomposition", "Jama.util.Maths", "java.lang.ArrayIndexOutOfBoundsException", "$.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.A = null;
this.m = 0;
this.n = 0;
Clazz.instantialize (this, arguments);
}, Jama, "Matrix", null, [Cloneable, java.io.Serializable]);
Clazz.makeConstructor (c$, 
function (m, n) {
this.m = m;
this.n = n;
this.A =  Clazz.newDoubleArray (m, n, 0);
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (m, n, s) {
this.m = m;
this.n = n;
this.A =  Clazz.newDoubleArray (m, n, 0);
for (var i = 0; i < m; i++) {
for (var j = 0; j < n; j++) {
this.A[i][j] = s;
}
}
}, "~N,~N,~N");
Clazz.makeConstructor (c$, 
function (A) {
this.m = A.length;
this.n = A[0].length;
for (var i = 0; i < this.m; i++) {
if (A[i].length != this.n) {
throw  new IllegalArgumentException ("All rows must have the same length.");
}}
this.A = A;
}, "~A");
Clazz.makeConstructor (c$, 
function (A, m, n) {
this.A = A;
this.m = m;
this.n = n;
}, "~A,~N,~N");
Clazz.makeConstructor (c$, 
function (vals, m) {
this.m = m;
this.n = (m != 0 ? Clazz.doubleToInt (vals.length / m) : 0);
if (m * this.n != vals.length) {
throw  new IllegalArgumentException ("Array length must be a multiple of m.");
}this.A =  Clazz.newDoubleArray (m, this.n, 0);
for (var i = 0; i < m; i++) {
for (var j = 0; j < this.n; j++) {
this.A[i][j] = vals[i + j * m];
}
}
}, "~A,~N");
c$.constructWithCopy = Clazz.defineMethod (c$, "constructWithCopy", 
function (A) {
var m = A.length;
var n = A[0].length;
var X =  new Jama.Matrix (m, n);
var C = X.getArray ();
for (var i = 0; i < m; i++) {
if (A[i].length != n) {
throw  new IllegalArgumentException ("All rows must have the same length.");
}for (var j = 0; j < n; j++) {
C[i][j] = A[i][j];
}
}
return X;
}, "~A");
Clazz.defineMethod (c$, "copy", 
function () {
var X =  new Jama.Matrix (this.m, this.n);
var C = X.getArray ();
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
C[i][j] = this.A[i][j];
}
}
return X;
});
Clazz.overrideMethod (c$, "clone", 
function () {
return this.copy ();
});
Clazz.defineMethod (c$, "getArray", 
function () {
return this.A;
});
Clazz.defineMethod (c$, "getArrayCopy", 
function () {
var C =  Clazz.newDoubleArray (this.m, this.n, 0);
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
C[i][j] = this.A[i][j];
}
}
return C;
});
Clazz.defineMethod (c$, "getColumnPackedCopy", 
function () {
var vals =  Clazz.newDoubleArray (this.m * this.n, 0);
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
vals[i + j * this.m] = this.A[i][j];
}
}
return vals;
});
Clazz.defineMethod (c$, "getRowPackedCopy", 
function () {
var vals =  Clazz.newDoubleArray (this.m * this.n, 0);
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
vals[i * this.n + j] = this.A[i][j];
}
}
return vals;
});
Clazz.defineMethod (c$, "getRowDimension", 
function () {
return this.m;
});
Clazz.defineMethod (c$, "getColumnDimension", 
function () {
return this.n;
});
Clazz.defineMethod (c$, "get", 
function (i, j) {
return this.A[i][j];
}, "~N,~N");
Clazz.defineMethod (c$, "getMatrix", 
function (i0, i1, j0, j1) {
var X =  new Jama.Matrix (i1 - i0 + 1, j1 - j0 + 1);
var B = X.getArray ();
try {
for (var i = i0; i <= i1; i++) {
for (var j = j0; j <= j1; j++) {
B[i - i0][j - j0] = this.A[i][j];
}
}
} catch (e) {
if (Clazz.exceptionOf (e, ArrayIndexOutOfBoundsException)) {
throw  new ArrayIndexOutOfBoundsException ("Submatrix indices");
} else {
throw e;
}
}
return X;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "getMatrix", 
function (r, c) {
var X =  new Jama.Matrix (r.length, c.length);
var B = X.getArray ();
try {
for (var i = 0; i < r.length; i++) {
for (var j = 0; j < c.length; j++) {
B[i][j] = this.A[r[i]][c[j]];
}
}
} catch (e) {
if (Clazz.exceptionOf (e, ArrayIndexOutOfBoundsException)) {
throw  new ArrayIndexOutOfBoundsException ("Submatrix indices");
} else {
throw e;
}
}
return X;
}, "~A,~A");
Clazz.defineMethod (c$, "getMatrix", 
function (i0, i1, c) {
var X =  new Jama.Matrix (i1 - i0 + 1, c.length);
var B = X.getArray ();
try {
for (var i = i0; i <= i1; i++) {
for (var j = 0; j < c.length; j++) {
B[i - i0][j] = this.A[i][c[j]];
}
}
} catch (e) {
if (Clazz.exceptionOf (e, ArrayIndexOutOfBoundsException)) {
throw  new ArrayIndexOutOfBoundsException ("Submatrix indices");
} else {
throw e;
}
}
return X;
}, "~N,~N,~A");
Clazz.defineMethod (c$, "getMatrix", 
function (r, j0, j1) {
var X =  new Jama.Matrix (r.length, j1 - j0 + 1);
var B = X.getArray ();
try {
for (var i = 0; i < r.length; i++) {
for (var j = j0; j <= j1; j++) {
B[i][j - j0] = this.A[r[i]][j];
}
}
} catch (e) {
if (Clazz.exceptionOf (e, ArrayIndexOutOfBoundsException)) {
throw  new ArrayIndexOutOfBoundsException ("Submatrix indices");
} else {
throw e;
}
}
return X;
}, "~A,~N,~N");
Clazz.defineMethod (c$, "set", 
function (i, j, s) {
this.A[i][j] = s;
}, "~N,~N,~N");
Clazz.defineMethod (c$, "setMatrix", 
function (i0, i1, j0, j1, X) {
try {
for (var i = i0; i <= i1; i++) {
for (var j = j0; j <= j1; j++) {
this.A[i][j] = X.get (i - i0, j - j0);
}
}
} catch (e) {
if (Clazz.exceptionOf (e, ArrayIndexOutOfBoundsException)) {
throw  new ArrayIndexOutOfBoundsException ("Submatrix indices");
} else {
throw e;
}
}
}, "~N,~N,~N,~N,Jama.Matrix");
Clazz.defineMethod (c$, "setMatrix", 
function (r, c, X) {
try {
for (var i = 0; i < r.length; i++) {
for (var j = 0; j < c.length; j++) {
this.A[r[i]][c[j]] = X.get (i, j);
}
}
} catch (e) {
if (Clazz.exceptionOf (e, ArrayIndexOutOfBoundsException)) {
throw  new ArrayIndexOutOfBoundsException ("Submatrix indices");
} else {
throw e;
}
}
}, "~A,~A,Jama.Matrix");
Clazz.defineMethod (c$, "setMatrix", 
function (r, j0, j1, X) {
try {
for (var i = 0; i < r.length; i++) {
for (var j = j0; j <= j1; j++) {
this.A[r[i]][j] = X.get (i, j - j0);
}
}
} catch (e) {
if (Clazz.exceptionOf (e, ArrayIndexOutOfBoundsException)) {
throw  new ArrayIndexOutOfBoundsException ("Submatrix indices");
} else {
throw e;
}
}
}, "~A,~N,~N,Jama.Matrix");
Clazz.defineMethod (c$, "setMatrix", 
function (i0, i1, c, X) {
try {
for (var i = i0; i <= i1; i++) {
for (var j = 0; j < c.length; j++) {
this.A[i][c[j]] = X.get (i - i0, j);
}
}
} catch (e) {
if (Clazz.exceptionOf (e, ArrayIndexOutOfBoundsException)) {
throw  new ArrayIndexOutOfBoundsException ("Submatrix indices");
} else {
throw e;
}
}
}, "~N,~N,~A,Jama.Matrix");
Clazz.defineMethod (c$, "transpose", 
function () {
var X =  new Jama.Matrix (this.n, this.m);
var C = X.getArray ();
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
C[j][i] = this.A[i][j];
}
}
return X;
});
Clazz.defineMethod (c$, "norm1", 
function () {
var f = 0;
for (var j = 0; j < this.n; j++) {
var s = 0;
for (var i = 0; i < this.m; i++) {
s += Math.abs (this.A[i][j]);
}
f = Math.max (f, s);
}
return f;
});
Clazz.defineMethod (c$, "norm2", 
function () {
return ( new Jama.SingularValueDecomposition (this).norm2 ());
});
Clazz.defineMethod (c$, "normInf", 
function () {
var f = 0;
for (var i = 0; i < this.m; i++) {
var s = 0;
for (var j = 0; j < this.n; j++) {
s += Math.abs (this.A[i][j]);
}
f = Math.max (f, s);
}
return f;
});
Clazz.defineMethod (c$, "normF", 
function () {
var f = 0;
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
f = Jama.util.Maths.hypot (f, this.A[i][j]);
}
}
return f;
});
Clazz.defineMethod (c$, "uminus", 
function () {
var X =  new Jama.Matrix (this.m, this.n);
var C = X.getArray ();
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
C[i][j] = -this.A[i][j];
}
}
return X;
});
Clazz.defineMethod (c$, "plus", 
function (B) {
this.checkMatrixDimensions (B);
var X =  new Jama.Matrix (this.m, this.n);
var C = X.getArray ();
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
C[i][j] = this.A[i][j] + B.A[i][j];
}
}
return X;
}, "Jama.Matrix");
Clazz.defineMethod (c$, "plusEquals", 
function (B) {
this.checkMatrixDimensions (B);
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
this.A[i][j] = this.A[i][j] + B.A[i][j];
}
}
return this;
}, "Jama.Matrix");
Clazz.defineMethod (c$, "minus", 
function (B) {
this.checkMatrixDimensions (B);
var X =  new Jama.Matrix (this.m, this.n);
var C = X.getArray ();
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
C[i][j] = this.A[i][j] - B.A[i][j];
}
}
return X;
}, "Jama.Matrix");
Clazz.defineMethod (c$, "minusEquals", 
function (B) {
this.checkMatrixDimensions (B);
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
this.A[i][j] = this.A[i][j] - B.A[i][j];
}
}
return this;
}, "Jama.Matrix");
Clazz.defineMethod (c$, "arrayTimes", 
function (B) {
this.checkMatrixDimensions (B);
var X =  new Jama.Matrix (this.m, this.n);
var C = X.getArray ();
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
C[i][j] = this.A[i][j] * B.A[i][j];
}
}
return X;
}, "Jama.Matrix");
Clazz.defineMethod (c$, "arrayTimesEquals", 
function (B) {
this.checkMatrixDimensions (B);
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
this.A[i][j] = this.A[i][j] * B.A[i][j];
}
}
return this;
}, "Jama.Matrix");
Clazz.defineMethod (c$, "arrayRightDivide", 
function (B) {
this.checkMatrixDimensions (B);
var X =  new Jama.Matrix (this.m, this.n);
var C = X.getArray ();
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
C[i][j] = this.A[i][j] / B.A[i][j];
}
}
return X;
}, "Jama.Matrix");
Clazz.defineMethod (c$, "arrayRightDivideEquals", 
function (B) {
this.checkMatrixDimensions (B);
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
this.A[i][j] = this.A[i][j] / B.A[i][j];
}
}
return this;
}, "Jama.Matrix");
Clazz.defineMethod (c$, "arrayLeftDivide", 
function (B) {
this.checkMatrixDimensions (B);
var X =  new Jama.Matrix (this.m, this.n);
var C = X.getArray ();
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
C[i][j] = B.A[i][j] / this.A[i][j];
}
}
return X;
}, "Jama.Matrix");
Clazz.defineMethod (c$, "arrayLeftDivideEquals", 
function (B) {
this.checkMatrixDimensions (B);
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
this.A[i][j] = B.A[i][j] / this.A[i][j];
}
}
return this;
}, "Jama.Matrix");
Clazz.defineMethod (c$, "times", 
function (s) {
var X =  new Jama.Matrix (this.m, this.n);
var C = X.getArray ();
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
C[i][j] = s * this.A[i][j];
}
}
return X;
}, "~N");
Clazz.defineMethod (c$, "timesEquals", 
function (s) {
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
this.A[i][j] = s * this.A[i][j];
}
}
return this;
}, "~N");
Clazz.defineMethod (c$, "times", 
function (B) {
if (B.m != this.n) {
throw  new IllegalArgumentException ("Matrix inner dimensions must agree.");
}var X =  new Jama.Matrix (this.m, B.n);
var C = X.getArray ();
var Bcolj =  Clazz.newDoubleArray (this.n, 0);
for (var j = 0; j < B.n; j++) {
for (var k = 0; k < this.n; k++) {
Bcolj[k] = B.A[k][j];
}
for (var i = 0; i < this.m; i++) {
var Arowi = this.A[i];
var s = 0;
for (var k = 0; k < this.n; k++) {
s += Arowi[k] * Bcolj[k];
}
C[i][j] = s;
}
}
return X;
}, "Jama.Matrix");
Clazz.defineMethod (c$, "lu", 
function () {
return  new Jama.LUDecomposition (this);
});
Clazz.defineMethod (c$, "eig", 
function (needVectors) {
return  new Jama.EigenvalueDecomposition (this, needVectors);
}, "~B");
Clazz.defineMethod (c$, "solve", 
function (B) {
return (this.m == this.n ? ( new Jama.LUDecomposition (this)).solve (B) : ( new Jama.QRDecomposition (this)).solve (B));
}, "Jama.Matrix");
Clazz.defineMethod (c$, "solveTranspose", 
function (B) {
return this.transpose ().solve (B.transpose ());
}, "Jama.Matrix");
Clazz.defineMethod (c$, "inverse", 
function () {
return this.solve (Jama.Matrix.identity (this.m, this.m));
});
Clazz.defineMethod (c$, "det", 
function () {
return  new Jama.LUDecomposition (this).det ();
});
Clazz.defineMethod (c$, "cond", 
function () {
return 0;
});
Clazz.defineMethod (c$, "trace", 
function () {
var t = 0;
for (var i = 0; i < Math.min (this.m, this.n); i++) {
t += this.A[i][i];
}
return t;
});
c$.random = Clazz.defineMethod (c$, "random", 
function (m, n) {
var A =  new Jama.Matrix (m, n);
var X = A.getArray ();
for (var i = 0; i < m; i++) {
for (var j = 0; j < n; j++) {
X[i][j] = Math.random ();
}
}
return A;
}, "~N,~N");
c$.identity = Clazz.defineMethod (c$, "identity", 
function (m, n) {
var A =  new Jama.Matrix (m, n);
var X = A.getArray ();
for (var i = 0; i < m; i++) {
for (var j = 0; j < n; j++) {
X[i][j] = (i == j ? 1.0 : 0.0);
}
}
return A;
}, "~N,~N");
Clazz.defineMethod (c$, "checkMatrixDimensions", 
 function (B) {
if (B.m != this.m || B.n != this.n) {
throw  new IllegalArgumentException ("Matrix dimensions must agree.");
}}, "Jama.Matrix");
});
