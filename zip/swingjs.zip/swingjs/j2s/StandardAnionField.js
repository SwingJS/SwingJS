Clazz.load (["javax.swing.JPanel", "java.awt.Font"], "edu.stonybrook.eserc.projectjava.chemicalcharge.StandardAnionField", ["java.awt.Dimension", "java.lang.Character"], function () {
c$ = Clazz.decorateAsClass (function () {
this.anionSymbol = null;
this.anionCharge = 0;
this.fontBig = null;
this.fontSmall = null;
Clazz.instantialize (this, arguments);
}, null, "StandardAnionField", javax.swing.JPanel);
Clazz.prepareFields (c$, function () {
this.fontBig =  new java.awt.Font ("TimesRoman", 1, 22);
this.fontSmall =  new java.awt.Font ("TimesRoman", 1, 12);
});
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, StandardAnionField, []);
});
Clazz.defineMethod (c$, "setStandardAnion", 
function (anionSymbol, anionCharge) {
this.anionSymbol = anionSymbol;
this.anionCharge = anionCharge;
this.repaint ();
}, "~S,~N");
Clazz.defineMethod (c$, "paintComponent", 
function (g) {
var position = 30;
Clazz.superCall (this, StandardAnionField, "paintComponent", [g]);
var fontMetricsBig = g.getFontMetrics (this.fontBig);
var fontMetricsSmall = g.getFontMetrics (this.fontSmall);
var na;
var i;
na = this.anionSymbol.length;
for (i = 0; i < na; i++) {
var ch = this.anionSymbol.charAt (i);
if (Character.isLetter (ch)) {
g.setFont (this.fontBig);
g.drawString ("" + ch, position, 20);
position += fontMetricsBig.stringWidth ("" + ch);
} else if (Character.isDigit (ch)) {
g.setFont (this.fontSmall);
g.drawString ("" + ch, position, 25);
position += fontMetricsSmall.stringWidth ("" + ch);
}}
g.setFont (this.fontSmall);
g.drawString ("" + this.anionCharge, position, 10);
}, "java.awt.Graphics");
Clazz.overrideMethod (c$, "getPreferredSize", 
function () {
return  new java.awt.Dimension (125, 32);
});
Clazz.overrideMethod (c$, "getMinimumSize", 
function () {
return  new java.awt.Dimension (125, 32);
});
});
