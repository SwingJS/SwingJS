Clazz.load (["javax.swing.JPanel", "java.awt.Font"], "edu.stonybrook.eserc.projectjava.chemicalcharge.StandardCationField", ["java.awt.Dimension", "java.lang.Character"], function () {
c$ = Clazz.decorateAsClass (function () {
this.cationSymbol = null;
this.cationCharge = 0;
this.fontBig = null;
this.fontSmall = null;
Clazz.instantialize (this, arguments);
}, null, "StandardCationField", javax.swing.JPanel);
Clazz.prepareFields (c$, function () {
this.fontBig =  new java.awt.Font ("TimesRoman", 1, 22);
this.fontSmall =  new java.awt.Font ("TimesRoman", 1, 12);
});
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, StandardCationField, []);
});
Clazz.defineMethod (c$, "setStandardCation", 
function (cationSymbol, cationCharge) {
this.cationSymbol = cationSymbol;
this.cationCharge = cationCharge;
this.repaint ();
}, "~S,~N");
Clazz.defineMethod (c$, "paintComponent", 
function (g) {
var position = 30;
Clazz.superCall (this, StandardCationField, "paintComponent", [g]);
var fontMetricsBig = g.getFontMetrics (this.fontBig);
var fontMetricsSmall = g.getFontMetrics (this.fontSmall);
var nc;
var i;
nc = this.cationSymbol.length;
for (i = 0; i < nc; i++) {
var ch = this.cationSymbol.charAt (i);
if (Character.isLetter (ch)) {
g.setFont (this.fontBig);
g.drawString ("" + ch, position, 20);
position += fontMetricsBig.stringWidth ("" + ch);
} else if (Character.isDigit (ch)) {
g.setFont (this.fontSmall);
g.drawString ("" + ch, position, 25);
position += fontMetricsSmall.stringWidth ("" + ch);
}}
g.setFont (this.fontSmall);
g.drawString ("+" + this.cationCharge, position, 10);
}, "java.awt.Graphics");
Clazz.overrideMethod (c$, "getPreferredSize", 
function () {
return  new java.awt.Dimension (100, 32);
});
Clazz.overrideMethod (c$, "getMinimumSize", 
function () {
return  new java.awt.Dimension (100, 32);
});
});
