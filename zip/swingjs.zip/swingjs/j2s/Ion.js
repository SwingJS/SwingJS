c$ = Clazz.decorateAsClass (function () {
this.name = null;
this.symbol = null;
this.charge = 0;
Clazz.instantialize (this, arguments);
}, null, "Ion");
Clazz.makeConstructor (c$, 
function (n, s, c) {
this.name = n;
this.symbol = s;
this.charge = c;
}, "~S,~S,~N");
Clazz.defineMethod (c$, "getName", 
function () {
return this.name;
});
Clazz.defineMethod (c$, "getSymbol", 
function () {
return this.symbol;
});
Clazz.defineMethod (c$, "getCharge", 
function () {
return this.charge;
});
Clazz.overrideMethod (c$, "toString", 
function () {
return this.name;
});
