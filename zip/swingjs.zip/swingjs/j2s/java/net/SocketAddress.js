Clazz.declarePackage ("java.net");
c$ = Clazz.declareType (java.net, "SocketAddress", null, java.io.Serializable);
