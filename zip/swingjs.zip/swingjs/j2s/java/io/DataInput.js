Clazz.declarePackage ("java.io");
Clazz.declareInterface (java.io, "DataInput");
