Clazz.load(["java.io.IOException"],"java.io.UnsupportedEncodingException",null,function(){
c$=Clazz.declareType(java.io,"UnsupportedEncodingException",java.io.IOException);
});
