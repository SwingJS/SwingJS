Clazz.declarePackage ("java.math");
c$ = Clazz.declareType (java.math, "BigDecimal");
Clazz.defineStatics (c$,
"ROUND_UP", 0,
"ROUND_DOWN", 1,
"ROUND_CEILING", 2,
"ROUND_FLOOR", 3,
"ROUND_HALF_UP", 4,
"ROUND_HALF_DOWN", 5,
"ROUND_HALF_EVEN", 6,
"ROUND_UNNECESSARY", 7);
