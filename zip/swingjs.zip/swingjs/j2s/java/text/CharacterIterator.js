Clazz.declarePackage ("java.text");
c$ = Clazz.declareInterface (java.text, "CharacterIterator", Cloneable);
Clazz.defineStatics (c$,
"DONE", '\uFFFF');
