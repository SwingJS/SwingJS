Clazz.declarePackage ("java.awt");
Clazz.load (["java.lang.Exception"], "java.awt.FontFormatException", null, function () {
c$ = Clazz.declareType (java.awt, "FontFormatException", Exception);
});
