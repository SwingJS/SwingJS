Clazz.declarePackage ("java.awt");
Clazz.load (["java.awt.Transparency"], "java.awt.Paint", null, function () {
Clazz.declareInterface (java.awt, "Paint", java.awt.Transparency);
});
