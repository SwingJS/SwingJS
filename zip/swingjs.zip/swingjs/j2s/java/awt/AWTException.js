Clazz.declarePackage ("java.awt");
Clazz.load (["java.lang.Exception"], "java.awt.AWTException", null, function () {
c$ = Clazz.declareType (java.awt, "AWTException", Exception);
});
