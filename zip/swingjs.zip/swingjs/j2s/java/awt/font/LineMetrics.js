Clazz.declarePackage ("java.awt.font");
c$ = Clazz.declareType (java.awt.font, "LineMetrics");
