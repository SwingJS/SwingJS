Clazz.declarePackage ("java.awt.geom");
Clazz.load (["java.lang.RuntimeException"], "java.awt.geom.IllegalPathStateException", null, function () {
c$ = Clazz.declareType (java.awt.geom, "IllegalPathStateException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.awt.geom.IllegalPathStateException, []);
});
});
