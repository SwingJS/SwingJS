Clazz.declarePackage ("java.awt.geom");
c$ = Clazz.declareInterface (java.awt.geom, "PathIterator");
Clazz.defineStatics (c$,
"WIND_EVEN_ODD", 0,
"WIND_NON_ZERO", 1,
"SEG_MOVETO", 0,
"SEG_LINETO", 1,
"SEG_QUADTO", 2,
"SEG_CUBICTO", 3,
"SEG_CLOSE", 4);
