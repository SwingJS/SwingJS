Clazz.declarePackage ("java.awt.geom");
Clazz.load (["java.lang.Exception"], "java.awt.geom.NoninvertibleTransformException", null, function () {
c$ = Clazz.declareType (java.awt.geom, "NoninvertibleTransformException", Exception);
});
