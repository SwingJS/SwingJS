Clazz.declarePackage ("java.awt");
c$ = Clazz.declareInterface (java.awt, "Transparency");
Clazz.defineStatics (c$,
"OPAQUE", 1,
"BITMASK", 2,
"TRANSLUCENT", 3);
