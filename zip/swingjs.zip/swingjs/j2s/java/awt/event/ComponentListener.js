Clazz.declarePackage ("java.awt.event");
Clazz.load (["java.util.EventListener"], "java.awt.event.ComponentListener", null, function () {
Clazz.declareInterface (java.awt.event, "ComponentListener", java.util.EventListener);
});
