Clazz.declarePackage ("java.awt.event");
Clazz.load (["java.util.EventListener"], "java.awt.event.HierarchyBoundsListener", null, function () {
Clazz.declareInterface (java.awt.event, "HierarchyBoundsListener", java.util.EventListener);
});
