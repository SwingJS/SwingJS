Clazz.declarePackage ("java.awt.event");
Clazz.load (["java.util.EventListener"], "java.awt.event.KeyListener", null, function () {
Clazz.declareInterface (java.awt.event, "KeyListener", java.util.EventListener);
});
