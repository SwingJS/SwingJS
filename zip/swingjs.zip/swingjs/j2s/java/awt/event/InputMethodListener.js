Clazz.declarePackage ("java.awt.event");
Clazz.load (["java.util.EventListener"], "java.awt.event.InputMethodListener", null, function () {
Clazz.declareInterface (java.awt.event, "InputMethodListener", java.util.EventListener);
});
