Clazz.declarePackage ("java.awt.event");
Clazz.load (["java.util.EventListener"], "java.awt.event.ActionListener", null, function () {
Clazz.declareInterface (java.awt.event, "ActionListener", java.util.EventListener);
});
