Clazz.declarePackage ("java.awt.event");
Clazz.load (["java.util.EventListener"], "java.awt.event.AdjustmentListener", null, function () {
Clazz.declareInterface (java.awt.event, "AdjustmentListener", java.util.EventListener);
});
