Clazz.declarePackage ("java.awt.event");
c$ = Clazz.declareType (java.awt.event, "NativeLibLoader");
c$.loadLibraries = Clazz.defineMethod (c$, "loadLibraries", 
function () {
});
