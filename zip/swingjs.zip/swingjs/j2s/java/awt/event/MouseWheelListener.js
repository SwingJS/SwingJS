Clazz.declarePackage ("java.awt.event");
Clazz.load (["java.util.EventListener"], "java.awt.event.MouseWheelListener", null, function () {
Clazz.declareInterface (java.awt.event, "MouseWheelListener", java.util.EventListener);
});
