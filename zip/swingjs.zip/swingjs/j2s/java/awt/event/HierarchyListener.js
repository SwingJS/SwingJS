Clazz.declarePackage ("java.awt.event");
Clazz.load (["java.util.EventListener"], "java.awt.event.HierarchyListener", null, function () {
Clazz.declareInterface (java.awt.event, "HierarchyListener", java.util.EventListener);
});
