Clazz.declarePackage ("java.awt.event");
Clazz.load (["java.util.EventListener"], "java.awt.event.ContainerListener", null, function () {
Clazz.declareInterface (java.awt.event, "ContainerListener", java.util.EventListener);
});
