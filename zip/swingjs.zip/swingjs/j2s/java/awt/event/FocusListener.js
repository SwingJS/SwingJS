Clazz.declarePackage ("java.awt.event");
Clazz.load (["java.util.EventListener"], "java.awt.event.FocusListener", null, function () {
Clazz.declareInterface (java.awt.event, "FocusListener", java.util.EventListener);
});
