Clazz.declarePackage ("java.awt.event");
Clazz.load (["java.util.EventListener"], "java.awt.event.WindowFocusListener", null, function () {
Clazz.declareInterface (java.awt.event, "WindowFocusListener", java.util.EventListener);
});
