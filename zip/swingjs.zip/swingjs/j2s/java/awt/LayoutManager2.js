Clazz.declarePackage ("java.awt");
Clazz.load (["java.awt.LayoutManager"], "java.awt.LayoutManager2", null, function () {
Clazz.declareInterface (java.awt, "LayoutManager2", java.awt.LayoutManager);
});
