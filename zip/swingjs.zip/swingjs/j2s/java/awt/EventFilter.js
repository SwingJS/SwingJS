Clazz.declarePackage ("java.awt");
Clazz.load (["java.lang.Enum"], "java.awt.EventFilter", null, function () {
Clazz.declareInterface (java.awt, "EventFilter");
Clazz.pu$h(self.c$);
c$ = Clazz.declareType (java.awt.EventFilter, "FilterAction", Enum);
Clazz.defineEnumConstant (c$, "ACCEPT", 0, []);
Clazz.defineEnumConstant (c$, "REJECT", 1, []);
Clazz.defineEnumConstant (c$, "ACCEPT_IMMEDIATELY", 2, []);
c$ = Clazz.p0p ();
});
