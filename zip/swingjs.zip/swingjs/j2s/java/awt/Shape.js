Clazz.declarePackage ("java.awt");
Clazz.declareInterface (java.awt, "Shape");
