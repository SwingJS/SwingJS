Clazz.declarePackage ("java.awt.image.renderable");
c$ = Clazz.declareInterface (java.awt.image.renderable, "RenderableImage");
Clazz.defineStatics (c$,
"HINTS_OBSERVED", "HINTS_OBSERVED");
