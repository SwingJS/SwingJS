Clazz.declarePackage ("java.awt.image");
c$ = Clazz.declareInterface (java.awt.image, "ImageConsumer");
Clazz.defineStatics (c$,
"RANDOMPIXELORDER", 1,
"TOPDOWNLEFTRIGHT", 2,
"COMPLETESCANLINES", 4,
"SINGLEPASS", 8,
"SINGLEFRAME", 16,
"IMAGEERROR", 1,
"SINGLEFRAMEDONE", 2,
"STATICIMAGEDONE", 3,
"IMAGEABORTED", 4);
