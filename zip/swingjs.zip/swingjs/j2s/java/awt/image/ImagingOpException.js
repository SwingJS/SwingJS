Clazz.declarePackage ("java.awt.image");
Clazz.load (["java.lang.RuntimeException"], "java.awt.image.ImagingOpException", null, function () {
c$ = Clazz.declareType (java.awt.image, "ImagingOpException", RuntimeException);
});
