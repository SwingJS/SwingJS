Clazz.declarePackage ("java.awt.image");
c$ = Clazz.declareInterface (java.awt.image, "ImageObserver");
Clazz.defineStatics (c$,
"WIDTH", 1,
"HEIGHT", 2,
"PROPERTIES", 4,
"SOMEBITS", 8,
"FRAMEBITS", 16,
"ALLBITS", 32,
"ERROR", 64,
"ABORT", 128);
