Clazz.declarePackage ("java.awt.image");
Clazz.load (["java.lang.RuntimeException"], "java.awt.image.RasterFormatException", null, function () {
c$ = Clazz.declareType (java.awt.image, "RasterFormatException", RuntimeException);
});
