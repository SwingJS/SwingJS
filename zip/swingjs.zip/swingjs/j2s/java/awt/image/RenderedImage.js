Clazz.declarePackage ("java.awt.image");
Clazz.declareInterface (java.awt.image, "RenderedImage");
