Clazz.declarePackage ("java.awt");
c$ = Clazz.declareInterface (java.awt, "Adjustable");
Clazz.defineStatics (c$,
"HORIZONTAL", 0,
"VERTICAL", 1,
"NO_ORIENTATION", 2);
