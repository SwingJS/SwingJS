Clazz.declarePackage ("java.awt");
Clazz.load (["java.lang.IllegalStateException"], "java.awt.IllegalComponentStateException", null, function () {
c$ = Clazz.declareType (java.awt, "IllegalComponentStateException", IllegalStateException);
});
