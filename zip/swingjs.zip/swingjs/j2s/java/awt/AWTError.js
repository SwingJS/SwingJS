Clazz.declarePackage ("java.awt");
Clazz.load (["java.lang.Error"], "java.awt.AWTError", null, function () {
c$ = Clazz.declareType (java.awt, "AWTError", Error);
});
