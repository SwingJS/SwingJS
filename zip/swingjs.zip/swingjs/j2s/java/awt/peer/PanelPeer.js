Clazz.declarePackage ("java.awt.peer");
Clazz.load (["java.awt.peer.ContainerPeer"], "java.awt.peer.PanelPeer", null, function () {
Clazz.declareInterface (java.awt.peer, "PanelPeer", java.awt.peer.ContainerPeer);
});
