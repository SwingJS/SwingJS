Clazz.declarePackage ("java.awt.peer");
Clazz.load (["java.awt.peer.ComponentPeer"], "java.awt.peer.LightweightPeer", null, function () {
Clazz.declareInterface (java.awt.peer, "LightweightPeer", java.awt.peer.ComponentPeer);
});
