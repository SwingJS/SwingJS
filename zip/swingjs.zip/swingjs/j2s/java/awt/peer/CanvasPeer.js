Clazz.declarePackage ("java.awt.peer");
Clazz.load (["java.awt.peer.ComponentPeer"], "java.awt.peer.CanvasPeer", null, function () {
Clazz.declareInterface (java.awt.peer, "CanvasPeer", java.awt.peer.ComponentPeer);
});
