Clazz.declarePackage ("java.awt.peer");
c$ = Clazz.declareInterface (java.awt.peer, "ComponentPeer");
Clazz.defineStatics (c$,
"SET_LOCATION", 1,
"SET_SIZE", 2,
"SET_BOUNDS", 3,
"SET_CLIENT_SIZE", 4,
"RESET_OPERATION", 5,
"NO_EMBEDDED_CHECK", (16384),
"DEFAULT_OPERATION", 3);
