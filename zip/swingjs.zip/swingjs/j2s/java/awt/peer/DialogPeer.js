Clazz.declarePackage ("java.awt.peer");
Clazz.load (["java.awt.peer.WindowPeer"], "java.awt.peer.DialogPeer", null, function () {
Clazz.declareInterface (java.awt.peer, "DialogPeer", java.awt.peer.WindowPeer);
});
