Clazz.declarePackage ("java.awt.peer");
Clazz.load (["java.awt.peer.ContainerPeer"], "java.awt.peer.WindowPeer", null, function () {
Clazz.declareInterface (java.awt.peer, "WindowPeer", java.awt.peer.ContainerPeer);
});
