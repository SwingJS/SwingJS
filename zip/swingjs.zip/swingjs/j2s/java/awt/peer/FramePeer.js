Clazz.declarePackage ("java.awt.peer");
Clazz.load (["java.awt.peer.WindowPeer"], "java.awt.peer.FramePeer", null, function () {
Clazz.declareInterface (java.awt.peer, "FramePeer", java.awt.peer.WindowPeer);
});
