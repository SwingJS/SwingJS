Clazz.declarePackage ("java.awt.peer");
Clazz.load (["java.awt.peer.ComponentPeer"], "java.awt.peer.ContainerPeer", null, function () {
Clazz.declareInterface (java.awt.peer, "ContainerPeer", java.awt.peer.ComponentPeer);
});
