Clazz.declarePackage ("java.applet");
Clazz.declareInterface (java.applet, "AppletStub");
