Clazz.declarePackage ("java.beans");
Clazz.declareInterface (java.beans, "PropertyEditor");
