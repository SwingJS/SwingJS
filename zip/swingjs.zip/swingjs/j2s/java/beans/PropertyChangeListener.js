Clazz.declarePackage ("java.beans");
Clazz.load (["java.util.EventListener"], "java.beans.PropertyChangeListener", null, function () {
Clazz.declareInterface (java.beans, "PropertyChangeListener", java.util.EventListener);
});
