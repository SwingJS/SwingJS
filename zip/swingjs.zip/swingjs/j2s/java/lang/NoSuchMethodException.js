Clazz.load(["java.lang.Exception"],"java.lang.NoSuchMethodException",null,function(){
c$=Clazz.declareType(java.lang,"NoSuchMethodException",Exception);
});
