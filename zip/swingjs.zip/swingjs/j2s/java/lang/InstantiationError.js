Clazz.load(["java.lang.IncompatibleClassChangeError"],"java.lang.InstantiationError",null,function(){
c$=Clazz.declareType(java.lang,"InstantiationError",IncompatibleClassChangeError);
});
