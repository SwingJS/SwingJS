Clazz.declareInterface(java.lang,"Readable");
