Clazz.declareInterface(java.lang.reflect,"GenericDeclaration");
