Clazz.load(["java.lang.reflect.Type"],"java.lang.reflect.TypeVariable",null,function(){
Clazz.declareInterface(java.lang.reflect,"TypeVariable",java.lang.reflect.Type);
});
