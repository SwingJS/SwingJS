Clazz.declarePackage ("java.security");
Clazz.declareInterface (java.security, "PrivilegedAction");
