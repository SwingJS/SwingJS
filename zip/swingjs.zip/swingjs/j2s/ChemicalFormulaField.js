Clazz.load (["javax.swing.JPanel", "java.awt.Font"], "edu.stonybrook.eserc.projectjava.chemicalcharge.ChemicalFormulaField", ["java.awt.Dimension", "java.lang.Character"], function () {
c$ = Clazz.decorateAsClass (function () {
this.cationSymbol = null;
this.cationCount = 0;
this.cationCharge = 0;
this.anionCharge = 0;
this.anionSymbol = null;
this.anionCount = 0;
this.cationTotalCharge = 0;
this.anionTotalCharge = 0;
this.netCharge = 0;
this.fontBig = null;
this.fontSmall = null;
Clazz.instantialize (this, arguments);
}, null, "ChemicalFormulaField", javax.swing.JPanel);
Clazz.prepareFields (c$, function () {
this.fontBig =  new java.awt.Font ("TimesRoman", 1, 25);
this.fontSmall =  new java.awt.Font ("TimesRoman", 1, 15);
});
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, ChemicalFormulaField, []);
});
Clazz.defineMethod (c$, "setFormula", 
function (cationSymbol, cationCount, cationTotalCharge, anionSymbol, anionCount, anionTotalCharge, netCharge) {
this.cationSymbol = cationSymbol;
this.cationCount = cationCount;
this.anionSymbol = anionSymbol;
this.anionCount = anionCount;
this.cationTotalCharge = cationTotalCharge;
this.anionTotalCharge = anionTotalCharge;
this.netCharge = netCharge;
this.repaint ();
}, "~S,~N,~N,~S,~N,~N,~N");
Clazz.defineMethod (c$, "paintComponent", 
function (g) {
var position = 45;
Clazz.superCall (this, ChemicalFormulaField, "paintComponent", [g]);
var fontMetricsBig = g.getFontMetrics (this.fontBig);
var fontMetricsSmall = g.getFontMetrics (this.fontSmall);
var nc;
var na;
var i;
nc = this.cationSymbol.length;
na = this.anionSymbol.length;
if ((this.cationCount == 0) && (this.anionCount == 0)) {
g.setFont (this.fontSmall);
g.drawString ("Please select from one ", 15, 15);
g.drawString ("of the buttons below.", 15, 30);
} else if ((this.cationCount > 0) && (this.anionCount == 0)) {
for (i = 0; i < nc; i++) {
var ch = this.cationSymbol.charAt (i);
if (Character.isLetter (ch) || (ch == '(') || (ch == ')')) {
if ((this.cationCount < 2) && ((ch == '(') || (ch == ')'))) {
} else {
g.setFont (this.fontBig);
g.drawString ("" + ch, position, 20);
position += fontMetricsBig.stringWidth ("" + ch);
}} else {
g.setFont (this.fontSmall);
g.drawString ("" + ch, position, 25);
position += fontMetricsSmall.stringWidth ("" + ch);
}}
if (this.cationCount > 1) {
g.setFont (this.fontSmall);
g.drawString ("" + this.cationCount, position, 25);
position += fontMetricsSmall.stringWidth ("" + this.cationCount);
}g.setFont (this.fontSmall);
g.drawString ("+" + this.cationTotalCharge, position, 10);
} else if ((this.cationCount == 0) && (this.anionCount > 0)) {
for (i = 0; i < na; i++) {
var ch = this.anionSymbol.charAt (i);
if (Character.isLetter (ch) || (ch == '(') || (ch == ')')) {
if ((this.anionCount < 2) && ((ch == '(') || (ch == ')'))) {
} else {
g.setFont (this.fontBig);
g.drawString ("" + ch, position, 20);
position += fontMetricsBig.stringWidth ("" + ch);
}} else {
g.setFont (this.fontSmall);
g.drawString ("" + ch, position, 25);
position += fontMetricsSmall.stringWidth ("" + ch);
}}
if (this.anionCount > 1) {
g.setFont (this.fontSmall);
g.drawString ("" + this.anionCount, position, 25);
position += fontMetricsSmall.stringWidth ("" + this.anionCount);
}g.setFont (this.fontSmall);
g.drawString ("" + this.anionTotalCharge, position, 10);
} else {
for (i = 0; i < nc; i++) {
var ch = this.cationSymbol.charAt (i);
if (Character.isLetter (ch) || (ch == '(') || (ch == ')')) {
if ((this.cationCount < 2) && ((ch == '(') || (ch == ')'))) {
} else {
g.setFont (this.fontBig);
g.drawString ("" + ch, position, 20);
position += fontMetricsBig.stringWidth ("" + ch);
}} else {
g.setFont (this.fontSmall);
g.drawString ("" + ch, position, 25);
position += fontMetricsSmall.stringWidth ("" + ch);
}}
if (this.cationCount > 1) {
g.setFont (this.fontSmall);
g.drawString ("" + this.cationCount, position, 25);
position += fontMetricsSmall.stringWidth ("" + this.cationCount);
}for (i = 0; i < na; i++) {
var ch = this.anionSymbol.charAt (i);
if (Character.isLetter (ch) || (ch == '(') || (ch == ')')) {
if ((this.anionCount < 2) && ((ch == '(') || (ch == ')'))) {
} else {
g.setFont (this.fontBig);
g.drawString ("" + ch, position, 20);
position += fontMetricsBig.stringWidth ("" + ch);
}} else {
g.setFont (this.fontSmall);
g.drawString ("" + ch, position, 25);
position += fontMetricsSmall.stringWidth ("" + ch);
}}
if (this.anionCount > 1) {
g.setFont (this.fontSmall);
g.drawString ("" + this.anionCount, position, 25);
position += fontMetricsSmall.stringWidth ("" + this.anionCount);
}g.setFont (this.fontSmall);
if (this.netCharge > 0) {
g.drawString ("+" + this.netCharge, position, 10);
} else if (this.netCharge < 0) {
g.drawString ("" + this.netCharge, position, 10);
}}}, "java.awt.Graphics");
Clazz.overrideMethod (c$, "getPreferredSize", 
function () {
return  new java.awt.Dimension (225, 52);
});
Clazz.overrideMethod (c$, "getMinimumSize", 
function () {
return  new java.awt.Dimension (225, 52);
});
});
